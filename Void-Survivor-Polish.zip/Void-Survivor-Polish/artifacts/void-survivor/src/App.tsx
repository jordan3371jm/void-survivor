import React, { useEffect, useRef, useState, useCallback } from 'react';
import type { GameState, LevelUpChoice, AbilityType } from './game/types';
import { getAbilityInfo } from './game/abilityInfo';
import { resumeAudio, setSfxVolume, setMusicVolume, loadCustomMusic, hasCustomMusic } from './game/audio';
import { t, Language, languageNames } from './game/i18n';
import { loadStore, saveStore, applyUpgrade, getUpgradeCost, GameStore, upgradeAbilityAttack, getAbilityAttackBonus, applyDiamondUpgrade, getDiamondUpgradeCost, applyCoinUpgrade, getCoinUpgradeCost, getStatLevel, getStatMaxLevel, DiamondUpgradeType, CoinUpgradeType, addHighScore, createUserProfile, saveUserProfile } from './game/store';
import { playgama } from './game/playgame';
import { AbilityIcon } from './components/abilityIcon';
import { ShipIcon } from './components/shipIcon';
import { checkAndCompleteAchievements } from './game/achievementChecker';
import { ArrowLeft, CalendarDays, Coins, Crosshair, Gem, Gift, Joystick, Music2, Pause, Rocket, Settings2, Shield, Sparkles, Star, Swords, Target, Trophy, UserRound, Volume2, Zap, FolderOpen } from 'lucide-react';

const ProfileModal = React.lazy(() => import('./profile').then((module) => ({ default: module.ProfileModal })));
const LeaderboardModal = React.lazy(() => import('./profile').then((module) => ({ default: module.LeaderboardModal })));
const AchievementsModal = React.lazy(() => import('./AchievementsModal').then((module) => ({ default: module.AchievementsModal })));
const DailyRewardModal = React.lazy(() => import('./DailyRewardModal').then((module) => ({ default: module.DailyRewardModal })));
const DailyEventsModal = React.lazy(() => import('./DailyEventsModal').then((module) => ({ default: module.DailyEventsModal })));

const ASSET_BASE_URL: string = ((import.meta as any).env && (import.meta as any).env.BASE_URL) || '/';
const BOSS_ICON_LIST = ['boss_death_star', 'boss_xenomorph', 'boss_cthulhu', 'boss_borg_cube', 'boss_space_kraken', 'boss_galaxy_devourer', 'boss_void_emperor', 'boss_cosmic_horror'];

type Screen = 'home' | 'upgrades' | 'ships' | 'settings' | 'playing';

const btnStyle = "font-bold hover:scale-110 transition-all duration-300 cursor-pointer";
const gradientText = { background: 'linear-gradient(90deg, #06b6d4, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' };

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameStateRef = useRef<GameState>(null as unknown as GameState);
  const gameEngineRef = useRef<typeof import('./game/engine') | null>(null);
  const gameEngineLoadRef = useRef<Promise<typeof import('./game/engine')> | null>(null);
  const startRunPendingRef = useRef(false);
  const animFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const runningRef = useRef<boolean>(false);
  const firstFrameRenderedRef = useRef<boolean>(false);

  const [screen, setScreen] = useState<Screen>('home');
  const [gameOver, setGameOver] = useState(false);
  const [levelUpPending, setLevelUpPending] = useState(false);
  const [levelUpChoices, setLevelUpChoices] = useState<LevelUpChoice[]>([]);
  const [finalScore, setFinalScore] = useState(0);
  const [finalTime, setFinalTime] = useState(0);
  const [finalKills, setFinalKills] = useState(0);
  const [finalLevel, setFinalLevel] = useState(0);
  const [finalCoins, setFinalCoins] = useState(0);
  const [finalDiamonds, setFinalDiamonds] = useState(0);
  const [finalPoints, setFinalPoints] = useState(0);
  const [paused, setPaused] = useState(false);
  const [upgradeTab, setUpgradeTab] = useState<'general' | 'active' | 'passive'>('general');
  const [store, setStore] = useState<GameStore>(loadStore());
  // Copia sempre aggiornata dello store: il game loop (useCallback) altrimenti userebbe una copia vecchia
  // e a fine partita sovrascriverebbe acquisti/miglioramenti fatti nel frattempo.
  const storeRef = useRef(store);
  storeRef.current = store;
  // true quando le statistiche della partita sono già state salvate alla morte (evita il doppio conteggio in endRun)
  const statsSavedRef = useRef(false);
  const [customMusicLoaded, setCustomMusicLoaded] = useState(false);
  const [customMusicName, setCustomMusicName] = useState('');
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showLeaderboardModal, setShowLeaderboardModal] = useState(false);
  const [doubleCoinsClaimed, setDoubleCoinsClaimed] = useState(false);
  const [revivePending, setRevivePending] = useState(false);
  const [showDamageStats, setShowDamageStats] = useState(false);
  const [showSpeedModal, setShowSpeedModal] = useState(false);
  const [speedBoostTimeLeft, setSpeedBoostTimeLeft] = useState(0);
  const [showAchievementsModal, setShowAchievementsModal] = useState(false);
  const [showModeSelection, setShowModeSelection] = useState(false);
  const [isStartingGame, setIsStartingGame] = useState(false);
  const [gameLoadError, setGameLoadError] = useState(false);
  const [showDailyRewardModal, setShowDailyRewardModal] = useState(false);
  const [showDailyEventsModal, setShowDailyEventsModal] = useState(false);


  const pausedRef = useRef(false);
  const levelUpShownRef = useRef(false);
  const gameOverShownRef = useRef(false);
  const reviveShownRef = useRef(false);
  const platformPausedRef = useRef(false); // pausa richiesta da Playgama
  const joystickRef = useRef<{ active: boolean; startX: number; startY: number; currentX: number; currentY: number }>({
    active: false, startX: 0, startY: 0, currentX: 0, currentY: 0
  });

  useEffect(() => {
    setSfxVolume(store.settings.sfxVolume);
    setMusicVolume(store.settings.musicVolume);
    setCustomMusicLoaded(hasCustomMusic());

    playgama.initialize().then(() => {
      if (playgama.isInitialized()) {
        // Pausa e audio richiesti dalla piattaforma (obbligatorio per la moderazione Playgama)
        playgama.onPauseChanged((paused) => { platformPausedRef.current = paused; });
        playgama.onAudioChanged((enabled) => {
          if (enabled) { setSfxVolume(store.settings.sfxVolume); setMusicVolume(store.settings.musicVolume); }
          else { setSfxVolume(0); setMusicVolume(0); }
        });
        playgama.sendGameReady();
      }
    }).catch((error: any) => {
      console.error('[App] Playgama SDK non disponibile:', error);
    });
  }, []);

  useEffect(() => {
    let cancelled = false;
    let unsubscribe = () => {};
    let timeoutId: number | undefined;
    let idleId: number | undefined;
    const idleWindow = window as Window & {
      requestIdleCallback?: (callback: () => void, options?: { timeout: number }) => number;
      cancelIdleCallback?: (handle: number) => void;
    };

    const connectAuth = async () => {
      try {
        const auth = await import('./game/auth');
        if (cancelled) return;
        unsubscribe = auth.observeAuth(async (user: any) => {
          if (user) {
            const currentStore = loadStore();
            const userId = user.uid || user.id;
            const userEmail = user.email || '';
            const userName = user.displayName || user.user_metadata?.username || user.user_metadata?.full_name || 'Player';
            const userAvatar = user.photoURL || user.user_metadata?.avatar_url || '👤';
            const userData = await auth.loadUserData(userId);

            if (userData) {
              const mergedStore = {
                ...currentStore,
                coins: userData.coins ?? currentStore.coins,
                diamonds: userData.diamonds ?? currentStore.diamonds,
                points: userData.points ?? currentStore.points,
                stats: { ...currentStore.stats, ...(userData.stats || {}) },
                upgrades: { ...currentStore.upgrades, ...(userData.upgrades || {}) },
                abilityAttackLevels: { ...currentStore.abilityAttackLevels, ...(userData.abilityAttackLevels || {}) },
                ships: { ...currentStore.ships, ...(userData.ships || {}) },
                currentShip: userData.currentShip || currentStore.currentShip,
                settings: { ...currentStore.settings, ...(userData.settings || {}) }
              };
              const profile = createUserProfile(userEmail, userName, userAvatar);
              profile.id = userId;
              profile.highScores = userData.highScores || [];
              const newStore = saveUserProfile(mergedStore, profile);
              setStore(newStore);
            } else if (!currentStore.userProfile || currentStore.userProfile.id !== userId) {
              const profile = createUserProfile(userEmail, userName, userAvatar);
              profile.id = userId;
              const newStore = saveUserProfile(currentStore, profile);
              setStore(newStore);
              await auth.saveUserData(userId, newStore);
            }
          } else {
            const currentStore = loadStore();
            if (currentStore.userProfile) {
              const newStore = { ...currentStore, userProfile: null };
              saveStore(newStore);
              setStore(newStore);
            }
          }
        });
      } catch (error) {
        console.error('[App] Authentication could not be initialized:', error);
      }
    };

    if (idleWindow.requestIdleCallback) {
      idleId = idleWindow.requestIdleCallback(() => void connectAuth(), { timeout: 2500 });
    } else {
      timeoutId = window.setTimeout(() => void connectAuth(), 900);
    }

    return () => {
      cancelled = true;
      if (timeoutId !== undefined) window.clearTimeout(timeoutId);
      if (idleId !== undefined) idleWindow.cancelIdleCallback?.(idleId);
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    const saveDataToFirestore = async () => {
      if (store.userProfile && store.userProfile.id) {
        try {
          const { saveUserData } = await import('./game/auth');
          await saveUserData(store.userProfile.id, store);
        } catch (error: any) {
          console.error('Errore salvataggio dati su Firestore:', error);
        }
      }
    };

    const timeoutId = setTimeout(saveDataToFirestore, 1000);
    return () => clearTimeout(timeoutId);
  }, [store.coins, store.diamonds, store.points, store.stats, store.upgrades, store.abilityAttackLevels, store.ships, store.currentShip, store.userProfile?.highScores]);



  useEffect(() => {
    if (gameOver) {
      const timer = setTimeout(() => {
        try {
          playgama.showInterstitial('game_over');
        } catch (error: any) {
          // Silenzioso - l'errore interstitial non è critico
        }
      }, 2000);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [gameOver]);

  // Timer per speed boost - si aggiorna in tempo reale (non influenzato dal speed multiplier)
  useEffect(() => {
    if (store.settings.speedBoostTimer <= 0) return;
    if (store.settings.speedBoostPaused) return; // Timer in pausa

    const interval = setInterval(() => {
      const newTimer = store.settings.speedBoostTimer - 1;
      
      // Aggiorna il timer
      const newStore = { 
        ...store, 
        settings: { 
          ...store.settings, 
          speedBoostTimer: newTimer 
        }
      };
      saveStore(newStore);
      setStore(newStore);
      setSpeedBoostTimeLeft(newTimer);
      
      // Controlla gli obiettivi ogni 10 secondi per performance
      if (newTimer % 10 === 0 && store.userProfile) {
        const updatedProfile = checkAndCompleteAchievements(store.userProfile as any, newTimer) as any;
        const storeWithProfile = { ...newStore, userProfile: updatedProfile };
        saveStore(storeWithProfile);
        setStore(storeWithProfile);
        console.log('[Speed Boost] ⏱️ Timer x2 attuale:', newTimer, 'secondi');
      }
      
      if (newTimer <= 0) {
        // Timer scaduto, torna a x1
        console.log('[Speed Boost] ⏱️ Timer scaduto!');
        const finalStore = { 
          ...store, 
          settings: { 
            ...store.settings, 
            speedMultiplier: 1.0, 
            speedBoostTimer: 0,
            speedBoostPaused: false
          } 
        };
        saveStore(finalStore);
        setStore(finalStore);
        setSpeedBoostTimeLeft(0);
      }
    }, 1000); // Aggiorna ogni secondo

    return () => clearInterval(interval);
  }, [store.settings.speedBoostTimer, store.settings.speedBoostPaused]);

  const handleMusicFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; if (!file) return;
    try { await loadCustomMusic(file); setCustomMusicLoaded(true); setCustomMusicName(file.name); }
    catch (error: any) { console.error(error); }
  };

  const lang = store.settings.language;
  const updateSetting = <K extends keyof typeof store.settings>(key: K, value: typeof store.settings[K]) => {
    const newStore = { ...store, settings: { ...store.settings, [key]: value } }; saveStore(newStore); setStore(newStore);
  };

  const ensureGameEngine = useCallback(async () => {
    if (gameEngineRef.current) return gameEngineRef.current;
    if (gameEngineLoadRef.current) return gameEngineLoadRef.current;
    setIsStartingGame(true);
    setGameLoadError(false);
    const engineLoad = import('./game/engine');
    gameEngineLoadRef.current = engineLoad;
    try {
      const engine = await engineLoad;
      gameEngineRef.current = engine;
      return engine;
    } catch (error) {
      setGameLoadError(true);
      console.error('[App] Unable to load the game engine:', error);
      throw error;
    } finally {
      gameEngineLoadRef.current = null;
      setIsStartingGame(false);
    }
  }, []);

  const gameLoop = useCallback((timestamp: number) => {
    if (!runningRef.current) return;

    try {
      const engine = gameEngineRef.current;
      const state = gameStateRef.current;
      if (!engine || !state) {
        runningRef.current = false;
        return;
      }

      const canvas = canvasRef.current;
      if (!canvas) {
        animFrameRef.current = requestAnimationFrame(gameLoop);
        return;
      }

      if (canvas.width === 0 || canvas.height === 0) {
        canvas.width = canvas.parentElement?.clientWidth || window.innerWidth || 800;
        canvas.height = canvas.parentElement?.clientHeight || window.innerHeight || 600;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        animFrameRef.current = requestAnimationFrame(gameLoop);
        return;
      }

      const dt = Math.min((timestamp - lastTimeRef.current) / 1000, 0.05);
      lastTimeRef.current = timestamp;

      if (!pausedRef.current && !platformPausedRef.current && !state.gameOver && !state.levelUpPending && !state.revivePending) engine.updateGame(state, dt);
      if (state.levelUpPending && !levelUpShownRef.current) { levelUpShownRef.current = true; setLevelUpChoices([...state.levelUpChoices]); setLevelUpPending(true); }
      if (state.revivePending && !reviveShownRef.current) {
        reviveShownRef.current = true;
        setRevivePending(true);
      }
      if (state.gameOver && !gameOverShownRef.current) {
        gameOverShownRef.current = true;
        const store = storeRef.current;
        const score = state.kills * 10 + Math.floor(state.time) * 5;
        setFinalScore(score); setFinalTime(state.time);
        setFinalKills(state.kills); setFinalLevel(state.player.level); setFinalCoins(state.coinsEarned);
        setFinalDiamonds(state.diamondsEarned); setFinalPoints(state.player.points); setGameOver(true);

        if (store.userProfile) {
          // Aggiorna high score locale
          const updatedStore = addHighScore(store, score, state.kills, state.time, state.player.level);

          // Aggiorna statistiche cumulative
          console.log('[App] 💀 gameOver - salvataggio statistiche...');
          
          // Se non c'è un profilo, creane uno locale automatico
          if (!updatedStore.userProfile) {
            console.log('[App] 🆕 Creazione profilo utente locale automatico...');
            const localProfile = createUserProfile(
              'local@player.com',
              'Giocatore Locale',
              '🎮'
            );
            updatedStore.userProfile = localProfile;
          }
          
          const currentProfile = updatedStore.userProfile!;
          // Un boss è stato sconfitto se c'era un boss attivo e ora non lo è più
          const bossWasDefeated = !state.bossActive && state.currentBossType !== null && state.kills > 0;
          let updatedProfile = {
            ...currentProfile,
            totalKills: (currentProfile.totalKills || 0) + state.kills,
            totalBossesDefeated: (currentProfile.totalBossesDefeated || 0) + (bossWasDefeated ? 1 : 0),
            abilityDamageStats: {
              ...currentProfile.abilityDamageStats,
              ...Object.fromEntries(
                Object.entries(state.abilityDamageStats || {}).map(([key, value]) => [
                  key,
                  (currentProfile.abilityDamageStats?.[key] || 0) + (value as number)
                ])
              )
            },
            // Statistiche per partita singola
            currentKills: state.kills,
            currentPlayTime: state.time,
            currentLevel: state.player.level,
            currentScore: state.score,
            currentWave: state.wave,
            // Statistiche totali
            totalPlayTime: (currentProfile.totalPlayTime || 0) + state.time,
            totalGamesPlayed: (currentProfile.totalGamesPlayed || 0) + 1,
            // Massimi
            maxLevel: Math.max(currentProfile.maxLevel || 0, state.player.level),
            maxScore: Math.max(currentProfile.maxScore || 0, state.score),
            maxWave: Math.max(currentProfile.maxWave || 0, state.wave)
          };

          console.log('[App] 📊 Statistiche aggiornate:', {
            currentKills: updatedProfile.currentKills,
            currentPlayTime: updatedProfile.currentPlayTime,
            currentLevel: updatedProfile.currentLevel,
            currentScore: updatedProfile.currentScore,
            currentWave: updatedProfile.currentWave,
            totalKills: updatedProfile.totalKills,
            totalBossesDefeated: updatedProfile.totalBossesDefeated,
            totalGamesPlayed: updatedProfile.totalGamesPlayed
          });

          // Controlla e completa gli obiettivi
          console.log('[App] 🎯 Controllo obiettivi...');
          updatedProfile = checkAndCompleteAchievements(updatedProfile as any, store.settings.speedBoostTimer) as any;

          const finalStore = saveUserProfile(updatedStore, updatedProfile);
          setStore(finalStore);
          statsSavedRef.current = true;
          console.log('[App] ✅ Salvataggio completato');

          // Salva punteggio globale
          console.log('[App] Chiamata saveGlobalScore con:', {
            id: currentProfile.id,
            name: currentProfile.name,
            avatar: currentProfile.avatar,
            score,
            kills: state.kills,
            time: state.time,
            level: state.player.level
          });

          void import('./game/auth').then(({ saveGlobalScore }) => saveGlobalScore(
            currentProfile.id,
            currentProfile.name,
            currentProfile.avatar,
            score,
            state.kills,
            state.time,
            state.player.level
          )).then(() => {
            console.log('[App] saveGlobalScore completato con successo');
          }).catch((err: any) => {
            console.error('[App] Errore salvataggio punteggio globale:', err);
          });
        }
      }
      engine.renderGame(ctx, state, canvas.width, canvas.height, store.settings.language, store.settings.showDamageNumbers);

      // Renderizza joystick se abilitato
      if (store.settings.useJoystick) {
        const joystick = joystickRef.current;
        const baseRadius = 60;
        const stickRadius = 30;

        // Posizione del joystick (in basso a sinistra se non attivo)
        const joystickX = joystick.active ? joystick.startX : 100;
        const joystickY = joystick.active ? joystick.startY : canvas.height - 100;
        const stickX = joystick.active ? joystick.currentX : joystickX;
        const stickY = joystick.active ? joystick.currentY : joystickY;

        ctx.save();

        // Base del joystick
        ctx.globalAlpha = 0.3;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(joystickX, joystickY, baseRadius, 0, Math.PI * 2);
        ctx.fill();

        ctx.globalAlpha = 0.5;
        ctx.strokeStyle = '#00ccff';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Stick del joystick
        ctx.globalAlpha = 0.6;
        ctx.fillStyle = '#00ccff';
        ctx.beginPath();
        ctx.arc(stickX, stickY, stickRadius, 0, Math.PI * 2);
        ctx.fill();

        ctx.globalAlpha = 0.8;
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.restore();
      }

      if (!firstFrameRenderedRef.current) {
        firstFrameRenderedRef.current = true;
      }
    } catch (error: any) { console.error('Game loop error:', error); }
    animFrameRef.current = requestAnimationFrame(gameLoop);
  }, [store.settings.language, store.settings.showDamageNumbers, store.settings.useJoystick]);

  const startGameLoop = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = canvas.parentElement?.clientWidth || window.innerWidth || 800;
    const height = canvas.parentElement?.clientHeight || window.innerHeight || 600;

    canvas.width = width;
    canvas.height = height;

    if (canvas.width === 0 || canvas.height === 0) {
      canvas.width = 800;
      canvas.height = 600;
    }

    runningRef.current = true;
    lastTimeRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(gameLoop);
  }, [gameLoop]);

  const stopGameLoop = useCallback(() => { runningRef.current = false; if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current); }, []);

  const startRun = useCallback(async (mode: 'normal' | 'endless' | 'boss_rush') => {
    if (startRunPendingRef.current) return;
    startRunPendingRef.current = true;
    resumeAudio();
    stopGameLoop();
    firstFrameRenderedRef.current = false;

    try {
      const engine = await ensureGameEngine();
      const currentState = gameStateRef.current;
      if (currentState && (currentState.coinsEarned > 0 || currentState.diamondsEarned > 0)) {
        const newStore = { ...store };
        newStore.coins += currentState.coinsEarned;
        newStore.diamonds += currentState.diamondsEarned;
        saveStore(newStore);
        setStore(newStore);
      }

      const newState = mode === 'normal'
        ? engine.createInitialState(store.currentShip as any)
        : engine.createInitialState(store.currentShip as any, mode);
      newState.player.maxHp = store.stats.maxHp || 100;
      newState.player.hp = store.stats.maxHp || 100;
      newState.player.damage = store.stats.attack || 10;
      newState.player.speed = store.stats.shipSpeed || 200;
      newState.player.armor = store.stats.defense || 0;
      newState.player.regenPerSecond = store.stats.regeneration || 0;
      newState.player.luckBonus = (store.stats.luck || 0) / 100;
      newState.player.expBonus = (store.stats.expBonus || 0) / 100;
      newState.player.critChance = store.stats.critChance || 0;
      newState.player.critDamage = store.stats.critDamage || 150;
      newState.player.abilityAttackBonuses = { ...store.abilityAttackLevels };

      gameStateRef.current = newState;
      pausedRef.current = false;
      gameOverShownRef.current = false;
      statsSavedRef.current = false;
      levelUpShownRef.current = false;
      reviveShownRef.current = false;
      setShowModeSelection(false);
      setScreen('playing');
      setGameOver(false);
      setLevelUpPending(false);
      setLevelUpChoices([]);
      setPaused(false);
      setDoubleCoinsClaimed(false);
      setRevivePending(false);
      setShowDamageStats(false);
    } catch (error) {
      setGameLoadError(true);
      setShowModeSelection(true);
      setScreen('home');
      console.error('[App] Unable to start a run:', error);
    } finally {
      startRunPendingRef.current = false;
    }
  }, [ensureGameEngine, stopGameLoop, store]);

  const startGame = useCallback(() => startRun('normal'), [startRun]);
  const startEndlessGame = useCallback(() => startRun('endless'), [startRun]);
  const startBossRushGame = useCallback(() => startRun('boss_rush'), [startRun]);

  const endRun = useCallback(() => {
    const currentState = gameStateRef.current; let newStore = { ...store };
    const statsAlreadySaved = statsSavedRef.current;
    newStore.coins += currentState.coinsEarned; newStore.diamonds += currentState.diamondsEarned; newStore.points += currentState.player.points;
    // Azzera i premi già incassati: altrimenti il prossimo startGame li riaccredita una seconda volta.
    currentState.coinsEarned = 0; currentState.diamondsEarned = 0; currentState.player.points = 0;
    
    // Salva statistiche partita nel profilo utente
    console.log('[App] 💾 endRun chiamato - salvataggio statistiche...');
    
    // Se non c'è un profilo, creane uno locale automatico
    if (!newStore.userProfile) {
      console.log('[App] 🆕 Creazione profilo utente locale automatico...');
      const localProfile = createUserProfile(
        'local@player.com',
        'Giocatore Locale',
        '🎮'
      );
      newStore.userProfile = localProfile;
    }
    
    if (newStore.userProfile && !statsAlreadySaved) {
      const profile = { ...newStore.userProfile };
      
      console.log('[App] 📊 Statistiche partita:', {
        kills: currentState.kills,
        time: currentState.time,
        level: currentState.player.level,
        score: currentState.score,
        wave: currentState.wave,
        bossActive: currentState.bossActive
      });
      
      // Aggiorna statistiche per partita singola
      profile.currentKills = currentState.kills;
      profile.currentPlayTime = currentState.time;
      profile.currentLevel = currentState.player.level;
      profile.currentScore = currentState.score;
      profile.currentWave = currentState.wave;
      
      // Aggiorna statistiche totali
      profile.totalKills = (profile.totalKills || 0) + currentState.kills;
      profile.totalPlayTime = (profile.totalPlayTime || 0) + currentState.time;
      profile.totalGamesPlayed = (profile.totalGamesPlayed || 0) + 1;
      
      // Aggiorna maxWave se necessario
      if (!profile.maxWave || currentState.wave > profile.maxWave) {
        profile.maxWave = currentState.wave;
      }
      
      // Aggiorna totalBossesDefeated se un boss è stato sconfitto
      // Un boss è stato sconfitto se bossActive è diventato false durante la partita
      // e ci sono stati kill (il boss è stato ucciso)
      const bossWasDefeated = !currentState.bossActive && currentState.currentBossType !== null && currentState.kills > 0;
      if (bossWasDefeated) {
        profile.totalBossesDefeated = (profile.totalBossesDefeated || 0) + 1;
        console.log('[App] 👹 Boss sconfitto! Totale:', profile.totalBossesDefeated);
      }
      
      // Aggiorna massimi se necessario
      if (!profile.maxLevel || currentState.player.level > profile.maxLevel) {
        profile.maxLevel = currentState.player.level;
      }
      if (!profile.maxScore || currentState.score > profile.maxScore) {
        profile.maxScore = currentState.score;
      }
      if (!profile.maxWave || currentState.wave > profile.maxWave) {
        profile.maxWave = currentState.wave;
      }
      
      // Il tempo x2 viene già salvato ogni secondo nel useEffect del timer
      // Non serve salvarlo qui
      
      console.log('[App] ✅ Statistiche aggiornate nel profilo');
      
      // Controlla e completa gli obiettivi
      const updatedProfile = checkAndCompleteAchievements(profile as any, store.settings.speedBoostTimer) as any;
      newStore.userProfile = updatedProfile;
      
      console.log('[App] 💾 Salvataggio...');
    }
    
    saveStore(newStore); setStore(newStore); stopGameLoop(); setScreen('home');
  }, [store, stopGameLoop]);

  const handleLevelUpChoice = useCallback((choice: LevelUpChoice) => {
    const state = gameStateRef.current;
    gameEngineRef.current?.applyLevelUpChoice(state, choice);
    levelUpShownRef.current = false; setLevelUpPending(false); setLevelUpChoices([]);
  }, []);

  const handleRevive = useCallback(async () => {
    try {
      const rewarded = await playgama.showRewarded('revive');
      if (rewarded) {
        const state = gameStateRef.current;
        gameEngineRef.current?.revivePlayer(state);
        reviveShownRef.current = false;
        setRevivePending(false);
      } else {
        const state = gameStateRef.current;
        state.gameOver = true;
        state.revivePending = false;
      }
    } catch (error: any) {
      console.error('Errore revive ad:', error);
      const state = gameStateRef.current;
      state.gameOver = true;
      state.revivePending = false;
    }
  }, []);

  const handleReviveDecline = useCallback(() => {
    const state = gameStateRef.current;
    state.gameOver = true;
    state.revivePending = false;
    reviveShownRef.current = false;
    setRevivePending(false);
  }, []);

  const togglePause = useCallback(() => {
    setPaused(p => { const newPaused = !p; pausedRef.current = newPaused; return newPaused; });
  }, []);

  useEffect(() => {
    if (screen !== 'playing') return;

    let resizeHandler: (() => void) | null = null;
    let resizeObserverInstance: ResizeObserver | null = null;

    // Avvia il game loop dopo un breve delay per assicurarsi che il canvas sia montato
    const startTimer = setTimeout(() => {
      const canvas = canvasRef.current;
      if (canvas) {
        resizeHandler = () => {
          const width = canvas.parentElement?.clientWidth || window.innerWidth || 800;
          const height = canvas.parentElement?.clientHeight || window.innerHeight || 600;
          canvas.width = width;
          canvas.height = height;
        };

        resizeHandler();

        window.addEventListener('resize', resizeHandler);

        resizeObserverInstance = new ResizeObserver(() => {
          if (resizeHandler) resizeHandler();
        });

        if (canvas.parentElement) {
          resizeObserverInstance.observe(canvas.parentElement);
        }

        // Avvia il game loop
        startGameLoop();

        setTimeout(() => { if (resizeHandler) resizeHandler(); }, 50);
        setTimeout(() => { if (resizeHandler) resizeHandler(); }, 100);
        setTimeout(() => { if (resizeHandler) resizeHandler(); }, 250);
        setTimeout(() => { if (resizeHandler) resizeHandler(); }, 500);
        setTimeout(() => { if (resizeHandler) resizeHandler(); }, 1000);
      }
    }, 100);

    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      gameStateRef.current.keys.add(key);
      if (!e.repeat && (e.key === 'Escape' || key === 'p')) togglePause();
    };
    const handleKeyUp = (e: KeyboardEvent) => { gameStateRef.current.keys.delete(e.key.toLowerCase()); };
    window.addEventListener('keydown', handleKeyDown); window.addEventListener('keyup', handleKeyUp);

    const handleTouchStart = (e: TouchEvent) => {
      if (levelUpPending || gameOver || paused) return;
      if (!store.settings.useJoystick) return;
      e.preventDefault();
      const touch = e.touches[0];
      joystickRef.current = {
        active: true,
        startX: touch.clientX,
        startY: touch.clientY,
        currentX: touch.clientX,
        currentY: touch.clientY
      };
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (levelUpPending || gameOver || paused) return;
      if (!store.settings.useJoystick || !joystickRef.current.active) return;
      e.preventDefault();
      const touch = e.touches[0];
      joystickRef.current.currentX = touch.clientX;
      joystickRef.current.currentY = touch.clientY;

      const dx = touch.clientX - joystickRef.current.startX;
      const dy = touch.clientY - joystickRef.current.startY;
      const distance = Math.sqrt(dx * dx + dy * dy);
      const maxDistance = 50;

      if (distance > 10) {
        const normalizedDx = dx / Math.max(distance, maxDistance);
        const normalizedDy = dy / Math.max(distance, maxDistance);

        const keys = gameStateRef.current.keys;
        keys.clear();
        if (normalizedDy < -0.3) keys.add('w');
        if (normalizedDy > 0.3) keys.add('s');
        if (normalizedDx < -0.3) keys.add('a');
        if (normalizedDx > 0.3) keys.add('d');
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (levelUpPending || gameOver || paused) return;
      if (!store.settings.useJoystick) return;
      e.preventDefault();
      joystickRef.current.active = false;
      gameStateRef.current.keys.clear();
    };

    // Controlli touch alternativi quando il joystick è disabilitato
    let touchStartData: { x: number; y: number } | null = null;

    const handleTouchStartAlt = (e: TouchEvent) => {
      if (levelUpPending || gameOver || paused || store.settings.useJoystick) return;
      e.preventDefault();
      const touch = e.touches[0];
      touchStartData = { x: touch.clientX, y: touch.clientY };
    };

    const handleTouchMoveAlt = (e: TouchEvent) => {
      if (levelUpPending || gameOver || paused || store.settings.useJoystick || !touchStartData) return;
      e.preventDefault();
      const touch = e.touches[0];
      const dx = touch.clientX - touchStartData.x;
      const dy = touch.clientY - touchStartData.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance > 10) {
        const keys = gameStateRef.current.keys;
        keys.clear();

        const absDx = Math.abs(dx);
        const absDy = Math.abs(dy);

        if (absDx > absDy) {
          if (dx > 0) keys.add('d');
          else keys.add('a');
        } else {
          if (dy > 0) keys.add('s');
          else keys.add('w');
        }

        if (distance > 30) {
          if (dx > 20) keys.add('d');
          else if (dx < -20) keys.add('a');
          if (dy > 20) keys.add('s');
          else if (dy < -20) keys.add('w');
        }
      }
    };

    const handleTouchEndAlt = (e: TouchEvent) => {
      if (levelUpPending || gameOver || paused || store.settings.useJoystick) return;
      e.preventDefault();
      touchStartData = null;
      gameStateRef.current.keys.clear();
    };

    if (store.settings.useJoystick) {
      window.addEventListener('touchstart', handleTouchStart, { passive: false });
      window.addEventListener('touchmove', handleTouchMove, { passive: false });
      window.addEventListener('touchend', handleTouchEnd, { passive: false });
    } else {
      window.addEventListener('touchstart', handleTouchStartAlt, { passive: false });
      window.addEventListener('touchmove', handleTouchMoveAlt, { passive: false });
      window.addEventListener('touchend', handleTouchEndAlt, { passive: false });
    }

    return () => {
      clearTimeout(startTimer);
      if (resizeHandler) window.removeEventListener('resize', resizeHandler);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      if (resizeObserverInstance) resizeObserverInstance.disconnect();
      if (store.settings.useJoystick) {
        window.removeEventListener('touchstart', handleTouchStart);
        window.removeEventListener('touchmove', handleTouchMove);
        window.removeEventListener('touchend', handleTouchEnd);
      } else {
        window.removeEventListener('touchstart', handleTouchStartAlt);
        window.removeEventListener('touchmove', handleTouchMoveAlt);
        window.removeEventListener('touchend', handleTouchEndAlt);
      }
    };
  }, [screen, togglePause, levelUpPending, gameOver, paused, store.settings.useJoystick, startGameLoop]);

  useEffect(() => () => { stopGameLoop(); }, [stopGameLoop]);

  useEffect(() => {
    window.scrollTo(0, 0);
    
    // Controlla gli obiettivi quando il giocatore torna alla home screen
    // Questo permette di completare obiettivi retroattivamente
    if (screen === 'home' && store.userProfile) {
      console.log('[App] 🏠 Home screen - controllo obiettivi retroattivo...');
      const profile = { ...store.userProfile };
      const updatedProfile = checkAndCompleteAchievements(profile as any, store.settings.speedBoostTimer) as any;
      
      if (JSON.stringify(profile) !== JSON.stringify(updatedProfile)) {
        console.log('[App] ✅ Nuovi obiettivi completati!');
        const newStore = { ...store, userProfile: updatedProfile };
        saveStore(newStore);
        setStore(newStore);
      }
    }
  }, [screen]);

  // SCHERMATA SELEZIONE MODALITÀ (deve venire prima di tutte le altre schermate)
  if (showModeSelection) {
    const maxWaveReached = store.userProfile?.maxWave || 0;
    const bossRushUnlocked = maxWaveReached >= 5;
    const endlessUnlocked = maxWaveReached >= 40;

    return (
      <div className="void-mode-select w-full h-screen flex flex-col items-center justify-center px-4 sm:px-6 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0a0015 0%, #1a0033 50%, #000022 100%)' }}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 20% 30%, rgba(147, 51, 234, 0.3) 0%, transparent 50%), radial-gradient(ellipse at 80% 70%, rgba(59, 130, 246, 0.25) 0%, transparent 50%)' }}></div>

        <div className="void-mode-panel relative z-10 w-full max-w-2xl">
          <p className="void-eyebrow text-center mb-2">
            {lang === 'it' ? 'SCEGLI LA TUA MISSIONE'
              : lang === 'es' ? 'ELIGE TU MISIÓN'
              : lang === 'fr' ? 'CHOISIS TA MISSION'
              : lang === 'zh' ? '选择你的任务'
              : 'SELECT YOUR MISSION'}
          </p>
          <h2 className="text-3xl sm:text-4xl font-black text-center mb-6 sm:mb-8" style={{ ...gradientText, filter: 'drop-shadow(0 0 20px rgba(168, 85, 247, 0.7))' }}>
            {t(lang, 'select_mode')}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
            {/* Modalità Normale */}
            <button
              onClick={startGame}
              disabled={isStartingGame}
              className="void-mode-card void-mode-card--normal p-4 sm:p-6 rounded-2xl transition-all hover:scale-105 active:scale-95 border-2"
              style={{
                background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.2) 0%, rgba(16, 185, 129, 0.2) 100%)',
                borderColor: 'rgba(34, 197, 94, 0.6)',
                boxShadow: '0 0 30px rgba(34, 197, 94, 0.3)'
              }}
            >
              <div className="void-mode-symbol"><Rocket size={38} /></div>
              <h3 className="text-lg sm:text-xl font-bold text-green-400 mb-2">{t(lang, 'normal_mode')}</h3>
              <p className="text-xs sm:text-sm text-gray-300 mb-3">{t(lang, 'normal_mode_desc')}</p>
              <div className="text-xs text-green-300 font-bold">
                {maxWaveReached > 0 ? `${t(lang, 'best_wave')}: ${maxWaveReached}` : t(lang, 'mode_unlocked')}
              </div>
            </button>

            {/* Modalità Boss Rush */}
            {bossRushUnlocked ? (
              <button
                onClick={startBossRushGame}
                disabled={isStartingGame}
                className="void-mode-card void-mode-card--boss p-4 sm:p-6 rounded-2xl transition-all hover:scale-105 active:scale-95 border-2"
                style={{
                  background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.2) 0%, rgba(220, 38, 38, 0.2) 100%)',
                  borderColor: 'rgba(239, 68, 68, 0.6)',
                  boxShadow: '0 0 30px rgba(239, 68, 68, 0.3)'
                }}
              >
                <div className="flex flex-wrap justify-center gap-1 mb-3">
                  {BOSS_ICON_LIST.map((b) => (
                    <img
                      key={b}
                      src={`${ASSET_BASE_URL}assets/icons/${b}.webp`}
                      alt=""
                      width={44}
                      height={44}
                      className="w-9 h-9 sm:w-11 sm:h-11 object-contain drop-shadow-[0_0_6px_rgba(239,68,68,0.6)]"
                      draggable={false}
                      onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                    />
                  ))}
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-red-400 mb-2">{t(lang, 'boss_rush')}</h3>
                <p className="text-xs sm:text-sm text-gray-300 mb-3">{t(lang, 'boss_rush_desc')}</p>
                <div className="text-xs text-red-300 font-bold">{t(lang, 'mode_unlocked')}</div>
              </button>
            ) : (
              <div
                className="void-mode-card void-mode-card--locked p-4 sm:p-6 rounded-2xl border-2 opacity-50 cursor-not-allowed"
                style={{
                  background: 'rgba(0, 0, 0, 0.3)',
                  borderColor: 'rgba(107, 114, 128, 0.3)'
                }}
              >
                <div className="void-mode-symbol"><Shield size={34} /></div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-400 mb-2">{t(lang, 'boss_rush')}</h3>
                <p className="text-xs sm:text-sm text-gray-500 mb-3">{t(lang, 'boss_rush_desc')}</p>
                <div className="text-xs text-gray-400 font-bold">
                  {lang === 'it' ? `Sblocca all'onda 5` : lang === 'en' ? `Unlock at wave 5` : lang === 'es' ? `Desbloquear en ola 5` : lang === 'fr' ? `Débloquer à la vague 5` : `在第5波解锁`}
                </div>
              </div>
            )}

            {/* Modalità Endless */}
            {endlessUnlocked ? (
              <button
                onClick={startEndlessGame}
                disabled={isStartingGame}
                className="void-mode-card void-mode-card--endless p-4 sm:p-6 rounded-2xl transition-all hover:scale-105 active:scale-95 border-2"
                style={{
                  background: 'linear-gradient(135deg, rgba(168, 85, 247, 0.2) 0%, rgba(139, 92, 246, 0.2) 100%)',
                  borderColor: 'rgba(168, 85, 247, 0.6)',
                  boxShadow: '0 0 30px rgba(168, 85, 247, 0.3)'
                }}
              >
                <div className="void-mode-symbol"><Star size={36} /></div>
                <h3 className="text-lg sm:text-xl font-bold text-purple-400 mb-2">{t(lang, 'endless_mode')}</h3>
                <p className="text-xs sm:text-sm text-gray-300 mb-3">{t(lang, 'endless_mode_desc')}</p>
                <div className="text-xs text-purple-300 font-bold">{t(lang, 'mode_unlocked')}</div>
              </button>
            ) : (
              <div
                className="void-mode-card void-mode-card--locked p-4 sm:p-6 rounded-2xl border-2 opacity-50 cursor-not-allowed"
                style={{
                  background: 'rgba(0, 0, 0, 0.3)',
                  borderColor: 'rgba(107, 114, 128, 0.3)'
                }}
              >
                <div className="void-mode-symbol"><Shield size={34} /></div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-400 mb-2">{t(lang, 'endless_mode')}</h3>
                <p className="text-xs sm:text-sm text-gray-500 mb-3">{t(lang, 'endless_mode_desc')}</p>
                <div className="text-xs text-gray-400 font-bold">
                  {lang === 'it' ? `Sblocca all'onda 40` : lang === 'en' ? `Unlock at wave 40` : lang === 'es' ? `Desbloquear en ola 40` : lang === 'fr' ? `Débloquer à la vague 40` : `在第40波解锁`}
                </div>
              </div>
            )}
          </div>

          {isStartingGame && (
            <div className="void-loading-state" role="status" aria-live="polite">
              <span className="void-spinner" aria-hidden="true" />
              <span>{lang === 'it' ? 'Preparazione partita…'
                : lang === 'es' ? 'Preparando partida…'
                : lang === 'fr' ? 'Préparation de la partie…'
                : lang === 'zh' ? '正在准备游戏…'
                : 'Preparing your run…'}</span>
            </div>
          )}
          {gameLoadError && !isStartingGame && (
            <p className="void-load-error" role="alert">
              {lang === 'it' ? 'Impossibile caricare la partita. Controlla la connessione e riprova.'
                : lang === 'es' ? 'No se pudo cargar la partida. Comprueba la conexión e inténtalo de nuevo.'
                : lang === 'fr' ? 'Impossible de charger la partie. Vérifiez votre connexion et réessayez.'
                : lang === 'zh' ? '无法加载游戏。请检查网络连接后重试。'
                : 'Could not load the game. Check your connection and try again.'}
            </p>
          )}

          <button
            onClick={() => setShowModeSelection(false)}
            disabled={isStartingGame}
            className="mt-6 sm:mt-8 w-full max-w-xs mx-auto px-6 py-3 rounded-xl font-bold text-white transition-all hover:scale-105 active:scale-95"
            style={{
              background: 'rgba(0, 0, 0, 0.5)',
              border: '2px solid rgba(255, 255, 255, 0.2)'
            }}
          >
            ← {t(lang, 'back')}
          </button>
        </div>
      </div>
    );
  }

  // HOME SCREEN
  if (screen === 'home') {
    // Calcola il numero di obiettivi completati non riscossi
    const unclaimedAchievements = store.userProfile?.completedAchievements?.filter(c => !c.claimed).length || 0;
    
    return (
      <div className="void-home w-full h-screen flex flex-col relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0a0015 0%, #1a0033 50%, #000022 100%)' }}>
        <div className="void-home-art absolute inset-0" aria-hidden="true" />

        {/* Indicatore x2 in alto a destra - cliccabile per attivare/disattivare */}
        {store.settings.speedMultiplier === 2 && (
          <button
            onClick={() => {
              const newStore = { 
                ...store, 
                settings: { 
                  ...store.settings, 
                  speedMultiplier: 1.0,
                  speedBoostPaused: true // Metti in pausa il timer
                } 
              };
              saveStore(newStore);
              setStore(newStore);
            }}
            className="fixed top-4 right-4 z-30 px-4 py-2 rounded-full bg-gradient-to-r from-purple-600/30 to-pink-600/30 border-2 border-purple-400/50 shadow-lg shadow-purple-500/30 hover:scale-110 active:scale-95 transition-all"
          >
            <span className="text-white/70 font-black text-xl">x2</span>
          </button>
        )}
        
        {/* Indicatore x2 in pausa - cliccabile per riattivare */}
        {store.settings.speedBoostPaused && store.settings.speedBoostTimer > 0 && (
          <button
            onClick={() => {
              const newStore = { 
                ...store, 
                settings: { 
                  ...store.settings, 
                  speedMultiplier: 2.0,
                  speedBoostPaused: false // Riattiva il boost
                } 
              };
              saveStore(newStore);
              setStore(newStore);
            }}
            className="fixed top-4 right-4 z-30 px-4 py-2 rounded-full bg-gradient-to-r from-gray-600/50 to-gray-700/50 border-2 border-gray-400/50 shadow-lg hover:scale-110 active:scale-95 transition-all"
          >
            <span className="text-white/50 font-black text-xl">Ⅱ x2</span>
          </button>
        )}

        <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 sm:px-6 py-4 sm:py-6">
          <div className="void-hero-ship" aria-hidden="true"><ShipIcon shipType={store.currentShip} color="#62f5cf" size={190} /></div>
          <h1 className="void-title font-black mb-6 sm:mb-8 text-center -mt-8 sm:mt-0" style={{
            ...gradientText,
            filter: 'drop-shadow(0 0 30px rgba(168, 85, 247, 0.7))',
            letterSpacing: '0.08em',
            lineHeight: '1.1'
          }}>
            <span className="block sm:hidden" style={{ fontSize: 'clamp(2.8rem, 11vw, 3.5rem)' }}>VOID</span>
            <span className="block sm:hidden" style={{ fontSize: 'clamp(2rem, 8vw, 2.5rem)', letterSpacing: '0.1em' }}>SURVIVORS</span>
            <span className="hidden sm:inline" style={{ fontSize: 'clamp(1.5rem, 6vw, 3rem)' }}>VOID SURVIVORS</span>
          </h1>

          <button
            onClick={() => setShowModeSelection(true)}
            className="mb-6 sm:mb-8 px-6 sm:px-10 py-3 sm:py-4 rounded-xl font-black transition-all hover:scale-105 active:scale-95"
            style={{
              ...gradientText,
              fontSize: 'clamp(1.1rem, 4vw, 1.5rem)',
              border: 'none',
              filter: 'drop-shadow(0 0 15px rgba(168, 85, 247, 0.5))'
            }}
          >
            <Rocket size={18} aria-hidden="true" /> {t(lang, 'startRun').replace(/^🚀\s*/u, '')}
          </button>

          <div className="flex flex-col gap-4 sm:gap-5 w-full max-w-[280px] sm:max-w-[320px]">
            <button
              onClick={() => {
                setShowModeSelection(false);
                setScreen('upgrades');
              }}
              className="w-full px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-black transition-all hover:scale-105 active:scale-95"
              style={{
                ...gradientText,
                fontSize: 'clamp(1rem, 3.5vw, 1.25rem)',
                border: 'none'
              }}
            >
              <Zap size={18} aria-hidden="true" /> {t(lang, 'upgrades')}
            </button>
            <button
              onClick={() => {
                setShowModeSelection(false);
                setScreen('ships');
              }}
              className="w-full px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-black transition-all hover:scale-105 active:scale-95"
              style={{
                ...gradientText,
                fontSize: 'clamp(1rem, 3.5vw, 1.25rem)',
                border: 'none'
              }}
            >
              <ShipIcon shipType="void_ship" color="#e35bff" size={25} /> {t(lang, 'astronavi')}
            </button>
            <button
              onClick={() => {
                setShowModeSelection(false);
                setScreen('settings');
              }}
              className="w-full px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-black transition-all hover:scale-105 active:scale-95"
              style={{
                ...gradientText,
                fontSize: 'clamp(1rem, 3.5vw, 1.25rem)',
                border: 'none'
              }}
            >
              <Settings2 size={18} aria-hidden="true" /> {t(lang, 'settings')}
            </button>
          </div>
        </div>

        {/* Monete e diamanti in basso al centro - versione desktop */}
        <div className="hidden sm:flex fixed bottom-4 left-1/2 transform -translate-x-1/2 z-20 flex-col items-center gap-1">
          <div className="text-base font-bold" style={{color: '#fbbf24'}}>
            <Coins size={15} /> {store.coins}
          </div>
          <div className="text-base font-bold" style={{color: '#06b6d4'}}>
            <Gem size={15} /> {store.diamonds}
          </div>
          {store.points > 0 && (
            <div className="text-base font-bold" style={{color: '#a855f7'}}>
              <Star size={15} /> {store.points}
            </div>
          )}
        </div>

        <div className="fixed bottom-4 left-4 right-4 z-20 sm:hidden">
          {/* Layout mobile: icone allineate con monete/diamanti */}
          <div className="flex items-end justify-between">
            {/* Colonna sinistra: icone */}
            <div className="flex flex-col gap-2 items-center">
              <button
                onClick={() => setShowDailyRewardModal(true)}
                className="w-11 h-11 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-yellow-500/50"
                title={t(lang, 'daily_reward')}
              >
                <Gift size={19} />
              </button>
              <button
                onClick={() => setShowAchievementsModal(true)}
                className="w-11 h-11 rounded-full bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center text-xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-orange-500/50 relative"
                title={t(lang, 'achievements')}
              >
                <Target size={19} />
                {unclaimedAchievements > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse border-2 border-white">
                    {unclaimedAchievements > 99 ? '99+' : unclaimedAchievements}
                  </span>
                )}
              </button>
              <button
                onClick={() => setShowProfileModal(true)}
                className="w-11 h-11 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center text-xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-purple-500/50"
                title={t(lang, 'profile')}
              >
                <UserRound size={19} />
              </button>
            </div>

            {/* Centro: monete e diamanti */}
            <div className="flex flex-col items-center gap-1">
              <div className="text-base font-bold" style={{color: '#fbbf24'}}>
                <Coins size={15} /> {store.coins}
              </div>
              <div className="text-base font-bold" style={{color: '#06b6d4'}}>
                <Gem size={15} /> {store.diamonds}
              </div>
              {store.points > 0 && (
                <div className="text-base font-bold" style={{color: '#a855f7'}}>
                  <Star size={15} /> {store.points}
                </div>
              )}
            </div>

            {/* Colonna destra: icone */}
            <div className="flex flex-col gap-2 items-center">
              <button
                onClick={() => setShowDailyEventsModal(true)}
                className="w-11 h-11 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center text-xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-green-500/50"
                title={t(lang, 'daily_events')}
              >
                <CalendarDays size={19} />
              </button>
              <button
                onClick={() => setShowSpeedModal(true)}
                className="w-11 h-11 rounded-full bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-cyan-500/50"
                title={t(lang, 'speed_select')}
              >
                <Zap size={19} />
              </button>
              <button
                onClick={() => setShowLeaderboardModal(true)}
                className="w-11 h-11 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center text-xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-yellow-500/50"
                title={t(lang, 'leaderboard')}
              >
                <Trophy size={19} />
              </button>
            </div>
          </div>
        </div>

        <div className="hidden sm:flex fixed bottom-4 left-4 z-20 flex-col gap-2 items-center">
          <button
            onClick={() => setShowDailyRewardModal(true)}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-2xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-yellow-500/50"
            title={t(lang, 'daily_reward')}
          >
            <Gift size={21} />
          </button>
          <button
            onClick={() => setShowAchievementsModal(true)}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center text-2xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-orange-500/50 relative"
            title={t(lang, 'achievements')}
          >
            <Target size={21} />
            {unclaimedAchievements > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse border-2 border-white">
                {unclaimedAchievements > 99 ? '99+' : unclaimedAchievements}
              </span>
            )}
          </button>
          <button
            onClick={() => setShowProfileModal(true)}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center text-2xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-purple-500/50"
            title={t(lang, 'profile')}
          >
            <UserRound size={21} />
          </button>
        </div>

        <div className="hidden sm:flex fixed bottom-4 right-4 z-20 flex-col gap-2 items-center">
          <button
            onClick={() => setShowDailyEventsModal(true)}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center text-2xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-green-500/50"
            title={t(lang, 'daily_events')}
          >
            <CalendarDays size={21} />
          </button>
          <button
            onClick={() => setShowSpeedModal(true)}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-2xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-cyan-500/50"
            title={t(lang, 'speed_select')}
          >
            <Zap size={21} />
          </button>
          <button
            onClick={() => setShowLeaderboardModal(true)}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center text-2xl hover:scale-110 active:scale-95 transition-all shadow-lg shadow-yellow-500/50"
            title={t(lang, 'leaderboard')}
          >
            <Trophy size={21} />
          </button>
        </div>

        <React.Suspense fallback={null}>
          {showProfileModal && <ProfileModal store={store} setStore={setStore} lang={lang} onClose={() => setShowProfileModal(false)} />}
          {showLeaderboardModal && <LeaderboardModal store={store} lang={lang} onClose={() => setShowLeaderboardModal(false)} />}
          {showAchievementsModal && <AchievementsModal store={store} setStore={setStore} lang={lang} onClose={() => setShowAchievementsModal(false)} />}
          {showDailyRewardModal && <DailyRewardModal store={store} setStore={setStore} lang={lang} onClose={() => setShowDailyRewardModal(false)} />}
          {showDailyEventsModal && <DailyEventsModal store={store} setStore={setStore} lang={lang} onClose={() => setShowDailyEventsModal(false)} />}
        </React.Suspense>
        {showSpeedModal && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-gradient-to-br from-cyan-900 to-blue-900 rounded-2xl p-6 max-w-md w-full border-2 border-cyan-500/50 max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white"><Zap size={20} /> {t(lang, 'speed_select')}</h2>
                <button onClick={() => setShowSpeedModal(false)} className="text-white text-2xl w-10 h-10 flex items-center justify-center">×</button>
              </div>
              
              {/* Velocità Attuale */}
              <div className="bg-black/30 rounded-xl p-4 mb-4">
                <p className="text-white font-bold text-center">{t(lang, 'speed_current')}: 
                  <span className="text-cyan-400 ml-2">
                    {store.settings.speedMultiplier === 1 && t(lang, 'speed_normal')}
                    {store.settings.speedMultiplier === 1.5 && t(lang, 'speed_fast')}
                    {store.settings.speedMultiplier === 2 && t(lang, 'speed_ultra')}
                  </span>
                </p>
                {store.settings.speedMultiplier > 1 && store.settings.speedBoostTimer > 0 && (
                  <p className="text-cyan-300 text-sm text-center mt-2">
                    {t(lang, 'speed_boost_timer')}: {Math.floor(store.settings.speedBoostTimer / 60)} {t(lang, 'speed_minutes')} {Math.floor(store.settings.speedBoostTimer % 60)} {t(lang, 'speed_seconds')}
                  </p>
                )}
              </div>

              {/* x1 - Normale */}
              <button
                onClick={() => {
                  const newStore = { ...store, settings: { ...store.settings, speedMultiplier: 1.0, speedBoostTimer: 0 } };
                  saveStore(newStore);
                  setStore(newStore);
                }}
                className="w-full mb-3 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-green-500/20 to-emerald-500/20 border-2 border-green-500/50 hover:bg-green-500/30 transition-all"
              >
                {t(lang, 'speed_normal')} {store.settings.speedMultiplier === 1 && '✓'}
              </button>

              {/* x1.5 - Veloce */}
              {store.userProfile && store.userProfile.totalBossesDefeated && store.userProfile.totalBossesDefeated >= 1 ? (
                <button
                  onClick={() => {
                    const newStore = { ...store, settings: { ...store.settings, speedMultiplier: 1.5, speedBoostTimer: 0 } };
                    saveStore(newStore);
                    setStore(newStore);
                  }}
                  className="w-full mb-3 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-2 border-cyan-500/50 hover:bg-cyan-500/30 transition-all"
                >
                  {t(lang, 'speed_fast')} {store.settings.speedMultiplier === 1.5 && '✓'}
                </button>
              ) : (
                <div className="w-full mb-3 py-3 rounded-xl font-bold text-gray-400 bg-gray-500/20 border-2 border-gray-500/50 cursor-not-allowed text-center">
                  {t(lang, 'speed_fast')}
                  <p className="text-xs mt-1">{t(lang, 'speed_requirement_boss1')}</p>
                </div>
              )}

              {/* x2 - Ultra */}
              {store.userProfile && store.userProfile.totalBossesDefeated && store.userProfile.totalBossesDefeated >= 5 ? (
                <button
                  onClick={() => {
                    // Accumula il timer (max 24 ore = 86400 secondi)
                    const currentTimer = store.settings.speedBoostTimer || 0;
                    const newTimer = Math.min(currentTimer + 600, 86400); // +10 minuti, max 24 ore
                    const newStore = { ...store, settings: { ...store.settings, speedMultiplier: 2.0, speedBoostTimer: newTimer } };
                    saveStore(newStore);
                    setStore(newStore);
                  }}
                  className="w-full mb-3 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-2 border-purple-500/50 hover:bg-purple-500/30 transition-all"
                >
                  {t(lang, 'speed_ultra')} {store.settings.speedMultiplier === 2 && '✓'}
                  <p className="text-xs mt-1">{t(lang, 'speed_permanent_unlock')} (+10 min)</p>
                </button>
              ) : (
                <div className="w-full mb-3">
                  <div className="py-3 rounded-xl font-bold text-gray-400 bg-gray-500/20 border-2 border-gray-500/50 cursor-not-allowed text-center mb-2">
                    {t(lang, 'speed_ultra')}
                    <p className="text-xs mt-1">{t(lang, 'speed_requirement_boss5')}</p>
                  </div>
                  <div className="bg-black/30 rounded-xl p-3 text-center">
                    <p className="text-white text-sm mb-2">{t(lang, 'speed_requirement_ads')}</p>
                    <p className="text-cyan-400 text-xs mb-2">{t(lang, 'speed_ads_watched')}: {store.settings.adsWatchedForSpeed}/5</p>
                    <button
                      onClick={async () => {
                        console.log('[Speed Boost] Tentativo di mostrare pubblicità...');
                        console.log('[Speed Boost] Playgama inizializzato:', playgama.isInitialized());
                        
                        if (!playgama.isInitialized()) {
                          console.warn('[Speed Boost] Playgama SDK non inizializzato. Assicurati di essere sulla piattaforma Playgama.');
                          // Invece di alert(), mostra un messaggio temporaneo
                          const btn = event?.currentTarget as HTMLButtonElement;
                          if (btn) {
                            const originalText = btn.textContent;
                            btn.textContent = '⚠️ Disponibile solo su Playgama';
                            btn.disabled = true;
                            setTimeout(() => {
                              btn.textContent = originalText;
                              btn.disabled = false;
                            }, 2000);
                          }
                          return;
                        }
                        
                        try {
                          const rewarded = await playgama.showRewarded('speed_boost');
                          console.log('[Speed Boost] Pubblicità completata, rewarded:', rewarded);
                          
                          if (rewarded) {
                            const newAdsWatched = store.settings.adsWatchedForSpeed + 1;
                            console.log('[Speed Boost] Pubblicità guardate:', newAdsWatched, '/5');
                            
                            if (newAdsWatched >= 5) {
                              console.log('[Speed Boost] +10 minuti di velocità x2!');
                              // Accumula il timer (max 24 ore = 86400 secondi)
                              const currentTimer = store.settings.speedBoostTimer || 0;
                              const newTimer = Math.min(currentTimer + 600, 86400); // +10 minuti, max 24 ore
                              console.log('[Speed Boost] Timer attuale:', currentTimer, 's → nuovo:', newTimer, 's');
                              const newStore = { ...store, settings: { ...store.settings, speedMultiplier: 2.0, speedBoostTimer: newTimer, adsWatchedForSpeed: 0 } };
                              saveStore(newStore);
                              setStore(newStore);
                            } else {
                              const newStore = { ...store, settings: { ...store.settings, adsWatchedForSpeed: newAdsWatched } };
                              saveStore(newStore);
                              setStore(newStore);
                            }
                          } else {
                            console.warn('[Speed Boost] Pubblicità non completata o annullata');
                          }
                        } catch (error) {
                          console.error('[Speed Boost] Errore durante la pubblicità:', error);
                          console.warn('[Speed Boost] Impossibile mostrare la pubblicità');
                        }
                      }}
                      className="w-full py-2 rounded-lg font-bold text-sm bg-gradient-to-r from-yellow-500/30 to-orange-500/30 border-2 border-yellow-500/60 text-yellow-300 hover:from-yellow-500/40 hover:to-orange-500/40 transition-all"
                    >
                      {t(lang, 'speed_activate_ads')} ({store.settings.adsWatchedForSpeed}/5)
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // UPGRADES SCREEN
  if (screen === 'upgrades') {
    return (
      <div className="void-upgrades w-full h-screen overflow-y-auto bg-gradient-to-br from-[#0a0015] via-[#1a0033] to-[#2d004d]">
        <div className="pt-24 pb-8 px-3 sm:px-4">
          <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-30 flex gap-4 text-sm">
            <span style={{color: '#f4c879', fontWeight: 'bold'}}><Coins size={15} /> {store.coins}</span>
            <span style={{color: '#70e9ed', fontWeight: 'bold'}}><Gem size={15} /> {store.diamonds}</span>
          </div>
          <button onClick={() => setScreen('home')} className={`void-back ${btnStyle}`}><ArrowLeft size={16} /> {t(lang, 'back')}</button>
          <div className="px-3 sm:px-4 max-w-4xl mx-auto">
            <h2 className="font-black text-center mb-4 sm:mb-6 text-2xl sm:text-3xl bg-gradient-to-r from-red-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">{t(lang, 'upgrades')}</h2>
            <div className="flex gap-1.5 sm:gap-2 mb-4 sm:mb-6 justify-center flex-wrap">
              {(['general', 'active', 'passive'] as const).map(tab => (
                <button key={tab} onClick={() => setUpgradeTab(tab)} className="px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg font-bold text-xs sm:text-sm transition-all" style={{ background: upgradeTab === tab ? 'rgba(168,85,247,0.3)' : 'rgba(0,0,0,0.4)', border: `2px solid ${upgradeTab === tab ? '#a855f7' : 'rgba(75,85,99,0.3)'}`, color: upgradeTab === tab ? '#a855f7' : '#9ca3af' }}>
                    {tab === 'general' && <Settings2 size={15} />} {tab === 'active' && <Swords size={15} />} {tab === 'passive' && <Shield size={15} />} {tab === 'general' ? t(lang, 'upgrades') : tab === 'active' ? t(lang, 'abilities') : t(lang, 'passive')}
                </button>
              ))}
            </div>
            {upgradeTab === 'general' && (
              <div>
                <h3 className="text-center text-lg font-bold text-yellow-400 mb-3"><Coins size={18} /> {t(lang, 'coin_upgrades').replace(/^💰\s*/u, '')}</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-6">
                  {([
                    { type: 'maxHp' as const, nameKey: 'hp', icon: <AbilityIcon type="passive_neutronium_heart" color="#ff738d" size={30} />, color: '#ff738d', unit: ' HP', format: (v: number) => (v || 100).toFixed(0), increment: '+5' },
                    { type: 'shipSpeed' as const, nameKey: 'stat_speed', icon: <AbilityIcon type="passive_ionic_thrusters" color="#55e8e1" size={30} />, color: '#55e8e1', unit: '', format: (v: number) => (v || 200).toFixed(0), increment: '+1' },
                    { type: 'defense' as const, nameKey: 'stat_defense', icon: <AbilityIcon type="passive_plating" color="#79baff" size={30} />, color: '#79baff', unit: '', format: (v: number) => (v || 0).toFixed(1), increment: '+0.1' },
                    { type: 'critChance' as const, nameKey: 'stat_crit_chance', icon: <AbilityIcon type="passive_stellar_fortune" color="#f4c879" size={30} />, color: '#f4c879', unit: '%', format: (v: number) => (v || 0).toFixed(1), increment: '+0.1%' },
                    { type: 'critDamage' as const, nameKey: 'stat_crit_damage', icon: <AbilityIcon type="passive_fusion_core" color="#ff738d" size={30} />, color: '#ff738d', unit: '%', format: (v: number) => (v || 150).toFixed(0), increment: '+1%' },
                    { type: 'regeneration' as const, nameKey: 'stat_regeneration', icon: <AbilityIcon type="passive_regen_core" color="#74e0b3" size={30} />, color: '#74e0b3', unit: '/s', format: (v: number) => (v || 0).toFixed(2), increment: '+0.01' },
                  ]).map(upgrade => {
                    const statValue = upgrade.type === 'maxHp' ? (store.stats.maxHp || 100) : (store.stats[upgrade.type as keyof typeof store.stats] || 0);
                    const level = upgrade.type === 'maxHp' ? (store.upgrades.maxHp?.level || 0) : getStatLevel(upgrade.type as any, statValue);
                    const maxLevel = upgrade.type === 'maxHp' ? (store.upgrades.maxHp?.maxLevel || 200) : getStatMaxLevel(upgrade.type as any);
                    const cost = upgrade.type === 'maxHp' ? getUpgradeCost(level) : getCoinUpgradeCost(upgrade.type as any, level);
                    const isMaxed = level >= maxLevel;
                    const canAfford = store.coins >= cost;

                    return (
                      <div key={upgrade.type} className="rounded-xl p-3 bg-black/60 border-2 transition-all hover:scale-105" style={{ borderColor: isMaxed ? 'rgba(34,197,94,0.5)' : canAfford ? upgrade.color + '80' : 'rgba(75,85,99,0.3)' }}>
                        <div className="text-center mb-2">
                          <span className="upgrade-glyph">{upgrade.icon}</span>
                          <h4 className="font-bold text-xs mt-1" style={{ color: upgrade.color }}>{t(lang, upgrade.nameKey)}</h4>
                          <p className="text-sm font-bold mt-1" style={{ color: upgrade.color }}>
                            {upgrade.format(statValue)}{upgrade.unit}
                          </p>
                          <p className="text-xs text-green-400 font-semibold mt-0.5">{upgrade.increment} / {t(lang, 'level')}</p>
                          <p className="text-xs text-gray-400">{t(lang, 'level')} {level}/{maxLevel}</p>
                        </div>
                        <button
                          onClick={() => {
                            if (upgrade.type === 'maxHp') {
                              const ns = applyUpgrade(store, 'maxHp');
                              if (ns) setStore(ns);
                            } else {
                              const ns = applyCoinUpgrade(store, upgrade.type as any);
                              if (ns) setStore(ns);
                            }
                          }}
                          disabled={isMaxed || !canAfford}
                          className="w-full py-1.5 rounded-lg font-bold text-xs"
                          style={{
                            background: isMaxed ? 'rgba(34,197,94,0.2)' : canAfford ? 'rgba(0,0,0,0.6)' : 'rgba(75,85,99,0.2)',
                            border: `2px solid ${isMaxed ? 'rgba(34,197,94,0.5)' : canAfford ? upgrade.color + '80' : 'rgba(75,85,99,0.3)'}`,
                            color: isMaxed ? '#22c55e' : canAfford ? upgrade.color : '#6b7280',
                            cursor: isMaxed || !canAfford ? 'not-allowed' : 'pointer'
                          }}
                        >
                          {isMaxed ? t(lang, 'maxLevel') : <><Coins size={13} /> {cost}</>}
                        </button>
                      </div>
                    );
                  })}
                </div>

                <h3 className="text-center text-lg font-bold text-cyan-400 mb-3"><Gem size={18} /> {t(lang, 'diamond_upgrades').replace(/^💎\s*/u, '')}</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {([
                    { type: 'luck' as DiamondUpgradeType, nameKey: 'stat_luck', icon: <AbilityIcon type="passive_stellar_fortune" color="#91d690" size={30} />, color: '#91d690', unit: '%', format: (v: number) => (v || 0).toFixed(0), increment: '+1%' },
                    { type: 'expBonus' as DiamondUpgradeType, nameKey: 'stat_exp', icon: <AbilityIcon type="passive_galactic_crown" color="#d8a2ff" size={30} />, color: '#d8a2ff', unit: '%', format: (v: number) => (v || 0).toFixed(0), increment: '+1%' },
                  ]).map(upgrade => {
                    const statValue = store.stats[upgrade.type] || 0;
                    const level = getStatLevel(upgrade.type, statValue);
                    const maxLevel = getStatMaxLevel(upgrade.type);
                    const cost = getDiamondUpgradeCost(upgrade.type, level);
                    const isMaxed = level >= maxLevel;
                    const canAfford = store.diamonds >= cost;

                    return (
                      <div key={upgrade.type} className="rounded-xl p-3 bg-black/60 border-2 transition-all hover:scale-105" style={{ borderColor: isMaxed ? 'rgba(34,197,94,0.5)' : canAfford ? upgrade.color + '80' : 'rgba(75,85,99,0.3)' }}>
                        <div className="text-center mb-2">
                          <span className="upgrade-glyph">{upgrade.icon}</span>
                          <h4 className="font-bold text-xs mt-1" style={{ color: upgrade.color }}>{t(lang, upgrade.nameKey)}</h4>
                          <p className="text-sm font-bold mt-1" style={{ color: upgrade.color }}>
                            {upgrade.format(statValue)}{upgrade.unit}
                          </p>
                          <p className="text-xs text-green-400 font-semibold mt-0.5">{upgrade.increment} / {t(lang, 'level')}</p>
                          <p className="text-xs text-gray-400">{t(lang, 'level')} {level}/{maxLevel}</p>
                        </div>
                        <button
                          onClick={() => { const ns = applyDiamondUpgrade(store, upgrade.type); if (ns) setStore(ns); }}
                          disabled={isMaxed || !canAfford}
                          className="w-full py-1.5 rounded-lg font-bold text-xs"
                          style={{
                            background: isMaxed ? 'rgba(34,197,94,0.2)' : canAfford ? 'rgba(0,0,0,0.6)' : 'rgba(75,85,99,0.2)',
                            border: `2px solid ${isMaxed ? 'rgba(34,197,94,0.5)' : canAfford ? upgrade.color + '80' : 'rgba(75,85,99,0.3)'}`,
                            color: isMaxed ? '#22c55e' : canAfford ? upgrade.color : '#6b7280',
                            cursor: isMaxed || !canAfford ? 'not-allowed' : 'pointer'
                          }}
                        >
                          {isMaxed ? t(lang, 'maxLevel') : <><Gem size={13} /> {cost}</>}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            {upgradeTab === 'active' && (
              <div>
                <h3 className="text-center text-lg font-bold text-red-400 mb-3"><Swords size={18} /> {t(lang, 'abilities')}</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {(['photon_gun', 'ion_gun', 'drone_swarm', 'gravity_waves', 'void_lance', 'cryo_lance', 'energy_shield', 'asteroid_fragment', 'homing_laser', 'laser_swords', 'plasma_flamethrower', 'gravity_field', 'ion_storm', 'antimatter_bomb', 'orbiting_satellites', 'corrosive_nebula', 'kinetic_darts', 'meteor', 'neutronium_boomerang', 'quantum_bounce', 'stellar_blackhole', 'probe_x', 'probe_y'] as AbilityType[]).map(type => {
                    const info = getAbilityInfo(type);
                    const atkLvl = getAbilityAttackBonus(store, type);
                    return (
                      <div key={type} className="rounded-xl p-3 bg-black/60 border-2 transition-all hover:scale-105" style={{ borderColor: info.color + '80' }}>
                        <div className="text-center mb-2">
                          <div className="w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                            <AbilityIcon type={type} color={info.color} size={48} />
                          </div>
                          <h4 className="font-bold text-xs" style={{ color: info.color }}>{t(lang, info.name)}</h4>
                          <p className="text-xs text-gray-400 mt-1">{t(lang, 'attack_level')}: {atkLvl}</p>
                        </div>
                        <button
                          onClick={() => { const ns = upgradeAbilityAttack(store, type); if (ns) setStore(ns); }}
                          disabled={store.coins < 100}
                          className="w-full py-1.5 rounded-lg font-bold text-xs"
                          style={{
                            background: store.coins >= 100 ? 'rgba(0,0,0,0.6)' : 'rgba(75,85,99,0.2)',
                            border: `1px solid ${info.color}80`,
                            color: store.coins >= 100 ? info.color : '#6b7280',
                            cursor: store.coins < 100 ? 'not-allowed' : 'pointer'
                          }}
                        >
                          <Sparkles size={13} /> +1 <Coins size={13} />100
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            {upgradeTab === 'passive' && (
              <div>
                <div className="mb-4 p-3 rounded-xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/50 text-center">
                  <p className="text-lg font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">{t(lang, 'coming_soon').replace(/^\p{Extended_Pictographic}\s*/u, '').replace(/\s*\p{Extended_Pictographic}$/u, '')}</p>
                  <p className="text-xs text-gray-400 mt-1">{t(lang, 'coming_soon_desc')}</p>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 sm:gap-3">
                  {(['passive_fusion_core', 'passive_plating', 'passive_neutronium_heart', 'passive_regen_core', 'passive_void_tome', 'passive_stellar_candelabrum', 'passive_kinetic_accelerator', 'passive_quantum_binder', 'passive_molecular_replicator', 'passive_ionic_thrusters', 'passive_gravity_field', 'passive_stellar_fortune', 'passive_galactic_crown', 'passive_cosmic_dust', 'passive_quantum_reactor', 'passive_pulsar_heart', 'passive_galactic_coin'] as AbilityType[]).map(type => {
                    const info = getAbilityInfo(type);
                    return (
                      <div key={type} className="rounded-xl p-2 sm:p-3 bg-black/60 border border-white/10 text-center">
                        <div className="w-8 h-8 mx-auto mb-1 flex items-center justify-center">
                          <AbilityIcon type={type} color={info.color} size={32} />
                        </div>
                        <h4 className="font-bold text-xs mt-1" style={{ color: info.color }}>{t(lang, info.name)}</h4>
                        <p className="text-xs text-gray-500 hidden sm:block">{t(lang, info.description)}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    );
  }

  // SHIPS SCREEN (ASTRONAVI)
  if (screen === 'ships') {
    return (
      <div className="void-ships w-full h-screen overflow-y-auto bg-gradient-to-br from-[#0a0015] via-[#1a0033] to-[#0f0025]">
        <div className="pt-24 pb-8 px-3 sm:px-4">
          <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-30 flex gap-4 text-sm">
            <span style={{color: '#f4c879', fontWeight: 'bold'}}><Coins size={15} /> {store.coins}</span>
            <span style={{color: '#70e9ed', fontWeight: 'bold'}}><Gem size={15} /> {store.diamonds}</span>
          </div>
          <button onClick={() => setScreen('home')} className={`void-back ${btnStyle}`}><ArrowLeft size={16} /> {t(lang, 'back')}</button>
          <div className="px-3 sm:px-4 max-w-6xl mx-auto">
            <h2 className="font-black text-center mb-4 sm:mb-8 text-2xl sm:text-3xl bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent"><ShipIcon shipType="void_ship" color="#ed75ff" size={32} /> {t(lang, 'astronavi')}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
              {[
                { type: 'starter', nameKey: 'ship_starter', price: 0, color: '#4a4a4a', ability: 'homing_laser' },
                { type: 'fire_ship', nameKey: 'ship_fire', price: 1000, color: '#ff4400', ability: 'plasma_flamethrower' },
                { type: 'laser_ship', nameKey: 'ship_laser', price: 1000, color: '#ff3333', ability: 'laser_swords' },
                { type: 'electric_ship', nameKey: 'ship_electric', price: 1000, color: '#5a5a5a', ability: 'ion_storm' },
                { type: 'nuclear_ship', nameKey: 'ship_nuclear', price: 1000, color: '#2a3a4a', ability: 'antimatter_bomb' },
                { type: 'shadow_ship', nameKey: 'ship_shadow', price: 1000, color: '#2a4a2a', ability: 'gravity_field' },
                { type: 'mechanical_ship', nameKey: 'ship_mechanical', price: 1000, color: '#888888', ability: 'orbiting_satellites' },
                { type: 'bio_ship', nameKey: 'ship_bio', price: 1000, color: '#3a2a2a', ability: 'corrosive_nebula' },
                { type: 'photon_ship', nameKey: 'ship_photon', price: 1500, color: '#ff3333', ability: 'photon_gun' },
                { type: 'ion_ship', nameKey: 'ship_ion', price: 1500, color: '#3333ff', ability: 'ion_gun' },
                { type: 'drone_ship', nameKey: 'ship_drone', price: 1500, color: '#ffaa00', ability: 'drone_swarm' },
                { type: 'gravity_ship', nameKey: 'ship_gravity', price: 1500, color: '#aa00ff', ability: 'gravity_waves' },
                { type: 'void_ship', nameKey: 'ship_void', price: 1500, color: '#660066', ability: 'void_lance' },
                { type: 'cryo_ship', nameKey: 'ship_cryo', price: 1500, color: '#00ffff', ability: 'cryo_lance' },
                { type: 'shield_ship', nameKey: 'ship_shield', price: 1500, color: '#00ff88', ability: 'energy_shield' },
                { type: 'asteroid_ship', nameKey: 'ship_asteroid', price: 1500, color: '#886644', ability: 'asteroid_fragment' },
                { type: 'kinetic_ship', nameKey: 'ship_kinetic', price: 1500, color: '#ff8800', ability: 'kinetic_darts' },
                { type: 'meteor_ship', nameKey: 'ship_meteor', price: 1500, color: '#ff6600', ability: 'meteor' },
                { type: 'boomerang_ship', nameKey: 'ship_boomerang', price: 1500, color: '#aaaaff', ability: 'neutronium_boomerang' },
                { type: 'quantum_ship', nameKey: 'ship_quantum', price: 1500, color: '#44ffff', ability: 'quantum_bounce' },
                { type: 'blackhole_ship', nameKey: 'ship_blackhole', price: 2000, color: '#000000', ability: 'stellar_blackhole' },
                { type: 'probe_x_ship', nameKey: 'ship_probe_x', price: 1500, color: '#ff2222', ability: 'probe_x' },
                { type: 'probe_y_ship', nameKey: 'ship_probe_y', price: 1500, color: '#2222ff', ability: 'probe_y' },
                { type: 'tie_fighter_ship', nameKey: 'ship_tie_fighter', price: 1800, color: '#2a2a2a', ability: 'kinetic_darts' },
                { type: 'viper_ship', nameKey: 'ship_viper', price: 1800, color: '#5a5a5a', ability: 'quantum_bounce' },
                { type: 'federation_ship', nameKey: 'ship_federation', price: 1800, color: '#cccccc', ability: 'energy_shield' },
              ].map(ship => {
                const owned = store.ships[ship.type as keyof typeof store.ships];
                const selected = store.currentShip === ship.type;
                const abilityInfo = getAbilityInfo(ship.ability as AbilityType);
                return (
                  <div key={ship.type} className={`void-ship-card rounded-2xl p-3 sm:p-4 bg-black/60 border-2 transition-all${selected ? ' is-selected' : ''}`} style={{ borderColor: selected ? ship.color : owned ? ship.color + '80' : 'rgba(75,85,99,0.3)' }}>
                    <div className="void-ship-art text-center mb-2 sm:mb-3 flex justify-center">
                      <ShipIcon shipType={ship.type} color={ship.color} size={80} />
                    </div>
                    <h3 className="font-bold text-center text-sm sm:text-base mb-2" style={{ color: ship.color }}>{t(lang, ship.nameKey)}</h3>
                    <div className="flex items-center justify-center gap-2 my-2 p-2 rounded-lg" style={{ background: `${abilityInfo.color}20`, border: `1px solid ${abilityInfo.color}40` }}>
                      <AbilityIcon type={ship.ability} color={abilityInfo.color} size={24} />
                      <span className="text-xs sm:text-sm font-bold" style={{ color: abilityInfo.color }}>{t(lang, abilityInfo.name)}</span>
                    </div>
                    <p className="text-sm text-gray-400 text-center mb-2">{ship.price === 0 ? t(lang, 'free') : owned ? t(lang, 'owned') : <><Coins size={13} /> {ship.price}</>}</p>
                    {!owned ? (
                      <button
                        onClick={() => { if (store.coins >= ship.price) { const ns = { ...store }; ns.coins -= ship.price; ns.ships[ship.type as keyof typeof ns.ships] = true; saveStore(ns); setStore(ns); } }}
                        disabled={store.coins < ship.price}
                        className="w-full py-2.5 rounded-lg font-bold text-sm"
                        style={{
                          background: 'rgba(0,0,0,0.6)',
                          border: `2px solid ${ship.color}80`,
                          color: store.coins >= ship.price ? ship.color : '#6b7280',
                          cursor: store.coins < ship.price ? 'not-allowed' : 'pointer'
                        }}
                      >
                        {t(lang, 'buy_ship')}
                      </button>
                    ) : (
                      <button
                        onClick={() => { if (!selected) { const ns = { ...store }; ns.currentShip = ship.type as any; saveStore(ns); setStore(ns); } }}
                        disabled={selected}
                        className="w-full py-2.5 rounded-lg font-bold text-sm"
                        style={{
                          background: selected ? `${ship.color}40` : 'rgba(0,0,0,0.6)',
                          border: `2px solid ${ship.color}`,
                          color: ship.color,
                          cursor: selected ? 'not-allowed' : 'pointer'
                        }}
                      >
                        {selected ? t(lang, 'selected') : t(lang, 'select')}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // SETTINGS SCREEN
  if (screen === 'settings') {
    return (
      <div className="void-settings w-full h-screen overflow-y-auto bg-gradient-to-br from-[#0f001a] via-[#1a0033] to-[#2d004d]">
        <div className="pt-24 pb-8 px-3 sm:px-4">
          <button onClick={() => setScreen('home')} className={`void-back ${btnStyle}`}><ArrowLeft size={16} /> {t(lang, 'back')}</button>
          <div className="void-settings-content px-4 max-w-3xl mx-auto">
            <h2 className="font-black text-center mb-8 text-3xl bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">{t(lang, 'settings')}</h2>
            <div className="space-y-6">
              <div className="rounded-2xl p-4 sm:p-6 bg-black/60 border-2 border-purple-500/50">
                <h3 className="font-bold text-base sm:text-lg text-purple-400 mb-3 sm:mb-4"><Sparkles size={17} /> {t(lang, 'language')}</h3>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 sm:gap-3">
                  {(Object.keys(languageNames) as Language[]).map(l => (
                    <button key={l} onClick={() => updateSetting('language', l)} className="py-3 px-4 rounded-xl font-bold transition-all" style={{ background: store.settings.language === l ? 'rgba(6,182,212,0.3)' : 'rgba(0,0,0,0.3)', border: `2px solid ${store.settings.language === l ? '#22d3ee' : 'rgba(75,85,99,0.3)'}`, color: store.settings.language === l ? '#22d3ee' : '#9ca3af' }}>
                      <div className="text-sm">{languageNames[l]}</div>
                    </button>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl p-4 sm:p-6 bg-black/60 border-2 border-orange-500/50">
                <div className="flex items-center gap-2 sm:gap-4 mb-3 sm:mb-4"><Volume2 size={20} className="text-orange-300" /><h3 className="font-bold text-sm sm:text-lg text-orange-400">{t(lang, 'sfxVolume')}</h3><span className="ml-auto font-bold text-sm sm:text-base text-orange-400">{Math.round(store.settings.sfxVolume * 100)}%</span></div>
                <input type="range" min="0" max="1" step="0.05" value={store.settings.sfxVolume} onChange={(e) => { const v = parseFloat(e.target.value); updateSetting('sfxVolume', v); setSfxVolume(v); }} className="w-full" />
              </div>
              <div className="rounded-2xl p-4 sm:p-6 bg-black/60 border-2 border-blue-500/50">
                <div className="flex items-center gap-2 sm:gap-4 mb-3 sm:mb-4"><Music2 size={20} className="text-cyan-300" /><h3 className="font-bold text-sm sm:text-lg text-blue-400">{t(lang, 'musicVolume')}</h3><span className="ml-auto font-bold text-sm sm:text-base text-blue-400">{Math.round(store.settings.musicVolume * 100)}%</span></div>
                <input type="range" min="0" max="1" step="0.05" value={store.settings.musicVolume} onChange={(e) => { const v = parseFloat(e.target.value); updateSetting('musicVolume', v); setMusicVolume(v); }} className="w-full" />
              </div>
              <div className="rounded-2xl p-4 sm:p-6 bg-black/60 border-2 border-pink-500/50">
                <h3 className="font-bold text-base sm:text-lg text-pink-400 mb-3 sm:mb-4"><Music2 size={17} /> {t(lang, 'custom_music')}</h3>
                {customMusicLoaded ? <p className="text-green-400 text-sm mb-4">{customMusicName}</p> : <p className="text-pink-300 text-sm mb-4">{t(lang, 'no_custom_music')}</p>}
                <label className="block w-full py-3 rounded-xl font-bold text-center cursor-pointer" style={{ background: 'rgba(0,0,0,0.6)', border: '2px solid rgba(236,72,153,0.8)', color: '#f472b6' }}>
                  <FolderOpen size={17} /> {customMusicLoaded ? t(lang, 'change_music') : t(lang, 'load_audio_file')}
                  <input type="file" accept="audio/*" onChange={handleMusicFileUpload} className="hidden" />
                </label>
              </div>
              <div className="rounded-2xl p-4 sm:p-6 bg-black/60 border-2 border-green-500/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 sm:gap-4">
                    <Crosshair size={20} className="text-emerald-300" />
                    <h3 className="font-bold text-sm sm:text-lg text-green-400">{t(lang, 'show_damage_numbers')}</h3>
                  </div>
                  <button
                    onClick={() => updateSetting('showDamageNumbers', !store.settings.showDamageNumbers)}
                    className="relative w-14 h-7 rounded-full transition-all duration-300"
                    style={{
                      background: store.settings.showDamageNumbers ? 'rgba(34, 197, 94, 0.6)' : 'rgba(75, 85, 99, 0.4)',
                      border: `2px solid ${store.settings.showDamageNumbers ? '#22c55e' : '#4b5563'}`
                    }}
                  >
                    <div
                      className="absolute top-0.5 w-5 h-5 rounded-full transition-all duration-300"
                      style={{
                        left: store.settings.showDamageNumbers ? 'calc(100% - 22px)' : '2px',
                        background: store.settings.showDamageNumbers ? '#22c55e' : '#6b7280',
                        boxShadow: store.settings.showDamageNumbers ? '0 0 10px rgba(34, 197, 94, 0.8)' : 'none'
                      }}
                    />
                  </button>
                </div>
              </div>
              <div className="rounded-2xl p-4 sm:p-6 bg-black/60 border-2 border-cyan-500/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 sm:gap-4">
                    <Joystick size={20} className="text-cyan-300" />
                    <div>
                      <h3 className="font-bold text-sm sm:text-lg text-cyan-400">{t(lang, 'virtual_joystick')}</h3>
                      <p className="text-xs text-gray-400 mt-1">{t(lang, 'virtual_joystick_desc')}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => updateSetting('useJoystick', !store.settings.useJoystick)}
                    className="relative w-14 h-7 rounded-full transition-all duration-300"
                    style={{
                      background: store.settings.useJoystick ? 'rgba(6, 182, 212, 0.6)' : 'rgba(75, 85, 99, 0.4)',
                      border: `2px solid ${store.settings.useJoystick ? '#06b6d4' : '#4b5563'}`
                    }}
                  >
                    <div
                      className="absolute top-0.5 w-5 h-5 rounded-full transition-all duration-300"
                      style={{
                        left: store.settings.useJoystick ? 'calc(100% - 22px)' : '2px',
                        background: store.settings.useJoystick ? '#06b6d4' : '#6b7280',
                        boxShadow: store.settings.useJoystick ? '0 0 10px rgba(6, 182, 212, 0.8)' : 'none'
                      }}
                    />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // PLAYING SCREEN
  if (screen === 'playing') {
    return (
      <div className="void-game-screen" style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100vw',
        height: '100dvh',
        overflow: 'hidden',
        backgroundColor: '#080713',
        zIndex: 9998
      }}>
        <canvas
          ref={canvasRef}
          className="void-game-canvas"
          width={typeof window !== 'undefined' ? window.innerWidth : 800}
          height={typeof window !== 'undefined' ? window.innerHeight : 600}
          style={{
            display: 'block',
            width: '100%',
            height: '100%',
            pointerEvents: (gameOver || levelUpPending || paused || revivePending) ? 'none' : 'auto',
          backgroundColor: '#080713'
          }}
        />

        <button
          type="button"
          className="void-mobile-pause"
          aria-label={t(lang, 'pause')}
          title={t(lang, 'pause')}
          onClick={togglePause}
          onPointerDown={(event) => event.stopPropagation()}
          onTouchStart={(event) => event.stopPropagation()}
        >
          <Pause size={18} aria-hidden="true" />
        </button>


        {levelUpPending && levelUpChoices.length > 0 && (
          <div className="void-game-overlay void-levelup-overlay fixed inset-0 flex items-center justify-center bg-black/85 backdrop-blur-sm z-[9999] overflow-y-auto py-4" style={{ pointerEvents: 'auto' }}>
            <div className="void-overlay-panel void-levelup-panel text-center p-3 sm:p-5 max-w-[900px] w-full" style={{ pointerEvents: 'auto' }}>
              <h2 className="font-black text-xl sm:text-2xl mb-1 sm:mb-2 bg-gradient-to-r from-yellow-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">{t(lang, 'level_up')}!</h2>
              <p className="text-gray-300 text-xs sm:text-sm mb-2 sm:mb-4">{t(lang, 'choose_upgrade')}</p>
              <div className="void-levelup-choices flex flex-col gap-2 sm:gap-3 items-center">
                {levelUpChoices.slice(0, 3).map((choice, i) => (
                  <button
                    key={i}
                    onClick={() => handleLevelUpChoice(choice)}
                    onPointerDown={(e) => e.stopPropagation()}
                    onTouchStart={(e) => { e.stopPropagation(); }}
                    className="void-levelup-choice w-full max-w-[340px] p-2.5 sm:p-4 rounded-xl sm:rounded-2xl text-left transition-all hover:scale-105 flex items-center gap-2 sm:gap-3"
                    style={{ background: 'rgba(20,20,40,0.95)', border: `3px solid ${choice.color}`, boxShadow: `0 0 40px ${choice.color}60`, touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent', cursor: 'pointer', position: 'relative', zIndex: 10000 }}
                  >
                    {choice.abilityType && (
                      <div className="flex-shrink-0">
                        <AbilityIcon type={choice.abilityType} color={choice.color} size={40} />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-xs sm:text-sm" style={{ color: choice.color }}>
                        {t(lang, choice.name)}
                        {choice.type === 'upgrade' && (() => {
                          const ability = gameStateRef.current.player.abilities.find(a => a.type === choice.abilityType);
                          return ability ? ` ${t(lang, 'level')} ${ability.level + 1}` : '';
                        })()}
                      </h3>
                      <p className="text-xs text-gray-300 truncate">{t(lang, choice.description)}</p>
                      <span className="text-xs font-bold mt-1 inline-block" style={{ color: choice.color }}>
                        {choice.type === 'ability' ? `✨ ${t(lang, 'new_ability')}` : choice.type === 'upgrade' ? `⚡ ${t(lang, 'upgrade_ability')}` : `💰 ${t(lang, 'gold_reward')}`}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
        {revivePending && !gameOver && !levelUpPending && !paused && (
          <div className="void-game-overlay void-revive-overlay fixed inset-0 flex items-center justify-center bg-black/90 backdrop-blur-sm z-[9999] overflow-y-auto" style={{ pointerEvents: 'auto' }}>
            <div className="void-overlay-panel text-center p-3 sm:p-6 max-w-[500px] w-full mx-3 sm:mx-4 my-4">
              <div className="mb-3 sm:mb-6">
                <div className="text-4xl sm:text-7xl mb-2 sm:mb-3 animate-pulse">💀</div>
                <h2 className="font-black text-lg sm:text-3xl mb-1 sm:mb-2 bg-gradient-to-r from-red-500 via-orange-500 to-red-500 bg-clip-text text-transparent">
                  {t(lang, 'defeated')}
                </h2>
                <p className="text-gray-300 text-xs sm:text-base mb-3 sm:mb-4">
                  {t(lang, 'continue_playing')}
                </p>
              </div>

              <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border-2 border-green-500/50 rounded-lg sm:rounded-xl p-3 sm:p-4 mb-3 sm:mb-4">
                <p className="text-green-400 font-bold text-sm sm:text-lg mb-1 sm:mb-2">{t(lang, 'revive_title')}</p>
                <p className="text-gray-300 text-xs sm:text-sm mb-2 sm:mb-3">
                  {t(lang, 'revive_description')}
                </p>
                <p className="text-gray-400 text-xs">
                  {t(lang, 'revive_warning')}
                </p>
              </div>

              <div className="flex flex-col gap-2 sm:gap-3">
                <button
                  onClick={handleRevive}
                  onPointerDown={(e) => e.stopPropagation()}
                  onTouchStart={(e) => { e.stopPropagation(); }}
                  className="w-full py-3 sm:py-4 rounded-lg sm:rounded-xl font-bold text-sm sm:text-lg transition-all hover:scale-105 active:scale-95"
                  style={{
                    background: 'linear-gradient(135deg, rgba(34, 197, 94, 0.3) 0%, rgba(16, 185, 129, 0.3) 100%)',
                    border: '2px solid rgba(34, 197, 94, 0.6)',
                    color: '#22c55e',
                    boxShadow: '0 0 20px rgba(34, 197, 94, 0.4)',
                    touchAction: 'manipulation',
                    WebkitTapHighlightColor: 'transparent',
                    cursor: 'pointer'
                  }}
                >
                  {t(lang, 'watch_ad_continue')}
                </button>
                <button
                  onClick={handleReviveDecline}
                  onPointerDown={(e) => e.stopPropagation()}
                  onTouchStart={(e) => { e.stopPropagation(); }}
                  className="w-full py-2 sm:py-3 rounded-lg sm:rounded-xl font-bold text-xs sm:text-base transition-all hover:scale-105 active:scale-95"
                  style={{
                    background: 'rgba(239, 68, 68, 0.2)',
                    border: '2px solid rgba(239, 68, 68, 0.5)',
                    color: '#ef4444',
                    touchAction: 'manipulation',
                    WebkitTapHighlightColor: 'transparent',
                    cursor: 'pointer'
                  }}
                >
                  {t(lang, 'dont_continue')}
                </button>
              </div>
            </div>
          </div>
        )}
        {paused && !gameOver && !levelUpPending && (
          <div className="void-game-overlay void-pause-overlay fixed inset-0 flex items-center justify-center z-[9998]" style={{ pointerEvents: 'auto', background: 'radial-gradient(ellipse at center, rgba(10, 0, 30, 0.95) 0%, rgba(0, 0, 0, 0.98) 100%)', backdropFilter: 'blur(10px)' }}>
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-20" style={{ background: 'radial-gradient(circle, rgba(139, 92, 246, 0.3) 0%, transparent 70%)', animation: 'pulse 4s ease-in-out infinite' }}></div>
              <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full opacity-20" style={{ background: 'radial-gradient(circle, rgba(6, 182, 212, 0.3) 0%, transparent 70%)', animation: 'pulse 4s ease-in-out infinite 2s' }}></div>
            </div>
            <div className="void-overlay-panel relative w-[90%] max-w-[600px] sm:max-w-[480px] md:max-w-[420px] mx-auto p-4 sm:p-5 md:p-6 rounded-2xl sm:rounded-3xl border-2" style={{ pointerEvents: 'auto', background: 'linear-gradient(135deg, rgba(20, 0, 50, 0.9) 0%, rgba(0, 20, 50, 0.9) 100%)', borderColor: 'rgba(139, 92, 246, 0.5)', boxShadow: '0 0 60px rgba(139, 92, 246, 0.3), inset 0 0 60px rgba(6, 182, 212, 0.1)' }}>
              <div className="text-center mb-4 sm:mb-5 md:mb-6">
                <h2 className="font-black text-2xl sm:text-3xl md:text-4xl mb-2 sm:mb-3" style={{ background: 'linear-gradient(90deg, #06b6d4, #a855f7, #ec4899)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', filter: 'drop-shadow(0 0 30px rgba(168, 85, 247, 0.5))' }}>
                  {t(lang, 'pause')}
                </h2>
                <p className="text-gray-400 text-xs sm:text-sm">{t(lang, 'pauseInfo')}</p>
              </div>
              <div className="grid grid-cols-2 gap-2 sm:gap-3 mb-4 sm:mb-5 md:mb-6 p-3 sm:p-4 rounded-xl sm:rounded-2xl" style={{ background: 'rgba(0, 0, 0, 0.4)', border: '1px solid rgba(139, 92, 246, 0.3)' }}>
                <div className="text-center">
                  <p className="text-gray-400 text-[10px] sm:text-xs mb-1">{t(lang, 'time')}</p>
                  <p className="text-cyan-400 text-lg sm:text-xl font-bold" style={{ textShadow: '0 0 10px rgba(6, 182, 212, 0.5)' }}>
                    {Math.floor(gameStateRef.current.time / 60)}:{Math.floor(gameStateRef.current.time % 60).toString().padStart(2, '0')}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-gray-400 text-[10px] sm:text-xs mb-1">{t(lang, 'level')}</p>
                  <p className="text-purple-400 text-lg sm:text-xl font-bold" style={{ textShadow: '0 0 10px rgba(168, 85, 247, 0.5)' }}>
                    {gameStateRef.current.player.level}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-gray-400 text-[10px] sm:text-xs mb-1">{t(lang, 'kills')}</p>
                  <p className="text-red-400 text-lg sm:text-xl font-bold" style={{ textShadow: '0 0 10px rgba(239, 68, 68, 0.5)' }}>
                    {gameStateRef.current.kills}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-gray-400 text-[10px] sm:text-xs mb-1">{t(lang, 'score')}</p>
                  <p className="text-yellow-400 text-lg sm:text-xl font-bold" style={{ textShadow: '0 0 10px rgba(250, 204, 21, 0.5)' }}>
                    {gameStateRef.current.score}
                  </p>
                </div>
              </div>
              <div className="flex flex-col gap-2 sm:gap-3">
                <button
                  onClick={togglePause}
                  onPointerDown={(e) => e.stopPropagation()}
                  onTouchStart={(e) => { e.stopPropagation(); }}
                  className="w-full py-3 sm:py-4 rounded-xl sm:rounded-2xl font-bold text-base sm:text-lg transition-all duration-300 hover:scale-105 active:scale-95"
                  style={{
                    touchAction: 'manipulation',
                    WebkitTapHighlightColor: 'transparent',
                    cursor: 'pointer',
                    position: 'relative',
                    zIndex: 10000,
                    background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.2) 0%, rgba(139, 92, 246, 0.2) 100%)',
                    border: '2px solid rgba(6, 182, 212, 0.6)',
                    color: '#06b6d4',
                    boxShadow: '0 0 20px rgba(6, 182, 212, 0.3), inset 0 0 20px rgba(6, 182, 212, 0.1)',
                    textShadow: '0 0 10px rgba(6, 182, 212, 0.8)'
                  }}
                >
                  {t(lang, 'resume')}
                </button>
                <button
                  onClick={endRun}
                  onPointerDown={(e) => e.stopPropagation()}
                  onTouchStart={(e) => { e.stopPropagation(); }}
                  className="w-full py-3 sm:py-4 rounded-xl sm:rounded-2xl font-bold text-base sm:text-lg transition-all duration-300 hover:scale-105 active:scale-95"
                  style={{
                    touchAction: 'manipulation',
                    WebkitTapHighlightColor: 'transparent',
                    cursor: 'pointer',
                    position: 'relative',
                    zIndex: 10000,
                    background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.2) 0%, rgba(236, 72, 153, 0.2) 100%)',
                    border: '2px solid rgba(239, 68, 68, 0.6)',
                    color: '#ef4444',
                    boxShadow: '0 0 20px rgba(239, 68, 68, 0.3), inset 0 0 20px rgba(239, 68, 68, 0.1)',
                    textShadow: '0 0 10px rgba(239, 68, 68, 0.8)'
                  }}
                >
                  {t(lang, 'home')}
                </button>
              </div>
            </div>
          </div>
        )}
        {gameOver && (
          <div className="void-game-overlay void-gameover-overlay fixed inset-0 flex items-center justify-center bg-black/85 backdrop-blur-sm z-[9999] overflow-y-auto py-4" style={{ pointerEvents: 'auto' }}>
            <div className="void-overlay-panel text-center max-w-[500px] w-full px-3 sm:px-5" style={{ pointerEvents: 'auto' }}>
              <h2 className="font-bold text-2xl sm:text-4xl mb-2 sm:mb-4 text-red-500">💀 {t(lang, 'gameOver')}</h2>
              <div className="bg-black/80 border-2 border-red-500/60 rounded-xl sm:rounded-2xl p-3 sm:p-6 mb-3 sm:mb-6">
                <div className="grid grid-cols-2 gap-2 sm:gap-4 text-left">
                  <div><p className="text-white text-xs sm:text-sm">{t(lang, 'time')}</p><p className="text-white text-base sm:text-xl font-bold">{Math.floor(finalTime / 60)}:{Math.floor(finalTime % 60).toString().padStart(2, '0')}</p></div>
                  <div><p className="text-white text-xs sm:text-sm">{t(lang, 'level')}</p><p className="text-cyan-400 text-base sm:text-xl font-bold">{finalLevel}</p></div>
                  <div><p className="text-white text-xs sm:text-sm">{t(lang, 'kills')}</p><p className="text-red-400 text-base sm:text-xl font-bold">{finalKills}</p></div>
                  <div><p className="text-white text-xs sm:text-sm">{t(lang, 'score')}</p><p className="text-yellow-400 text-base sm:text-xl font-bold">{finalScore}</p></div>
                </div>
                <div className="mt-2 sm:mt-4 pt-2 sm:pt-4 border-t border-red-500/40 flex justify-around">
                  <div className="text-center"><p className="text-yellow-400 text-base sm:text-xl font-bold">💰 +{finalCoins}</p><p className="text-white text-xs">{t(lang, 'coins')}</p></div>
                  <div className="text-center"><p className="text-cyan-400 text-base sm:text-xl font-bold">💎 +{finalDiamonds}</p><p className="text-white text-xs">{t(lang, 'diamonds')}</p></div>
                  {finalPoints > 0 && <div className="text-center"><p className="text-purple-400 text-base sm:text-xl font-bold">⭐ +{finalPoints}</p><p className="text-white text-xs">{t(lang, 'score')}</p></div>}
                </div>
              </div>

              {/* Pulsante Danni Totali */}
              <button
                onClick={() => setShowDamageStats(true)}
                className="w-full mb-3 py-3 rounded-xl font-bold text-sm sm:text-base transition-all hover:scale-105 active:scale-95"
                style={{
                  touchAction: 'manipulation',
                  WebkitTapHighlightColor: 'transparent',
                  cursor: 'pointer',
                  background: 'linear-gradient(135deg, rgba(168, 85, 247, 0.3) 0%, rgba(236, 72, 153, 0.3) 100%)',
                  border: '2px solid rgba(168, 85, 247, 0.6)',
                  color: '#a855f7',
                  boxShadow: '0 0 20px rgba(168, 85, 247, 0.3)'
                }}
              >
                ⚔️ {t(lang, 'total_damage')}
              </button>

              {!doubleCoinsClaimed && finalCoins > 0 && (
                <button
                  onClick={async (event) => {
                    console.log('[Double Coins] Tentativo di mostrare pubblicità...');
                    
                    if (!playgama.isInitialized()) {
                      console.warn('[Double Coins] Playgama SDK non inizializzato');
                      // Invece di alert(), mostra un messaggio temporaneo
                      const btn = event?.currentTarget as HTMLButtonElement;
                      if (btn) {
                        const originalText = btn.textContent;
                        btn.textContent = '⚠️ Disponibile solo su Playgama';
                        btn.disabled = true;
                        setTimeout(() => {
                          btn.textContent = originalText;
                          btn.disabled = false;
                        }, 2000);
                      }
                      return;
                    }
                    
                    try {
                      const rewarded = await playgama.showRewarded('double_coins');
                      console.log('[Double Coins] Pubblicità completata, rewarded:', rewarded);
                      
                      if (rewarded) {
                        const newStore = { ...store, coins: store.coins + finalCoins };
                        saveStore(newStore);
                        setStore(newStore);
                        setDoubleCoinsClaimed(true);
                      }
                    } catch (error: any) {
                      console.error('[Double Coins] Errore rewarded ad:', error);
                      // Invece di alert(), log solo l'errore
                      console.warn('[Double Coins] Impossibile mostrare la pubblicità');
                    }
                  }}
                  className="w-full mb-3 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-yellow-500/30 to-orange-500/30 border-2 border-yellow-500/60 text-yellow-300 hover:from-yellow-500/40 hover:to-orange-500/40 transition-all"
                  style={{ touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent', cursor: 'pointer', position: 'relative', zIndex: 10000 }}
                >
                  🎬 {t(lang, 'watch_ad_double_coins')} (+{finalCoins} 💰)
                </button>
              )}
              {doubleCoinsClaimed && finalCoins > 0 && (
                <div className="w-full mb-3 py-3 rounded-xl font-bold text-sm bg-green-500/20 border-2 border-green-500/50 text-green-300 text-center">
                  ✅ {t(lang, 'reward_already_claimed')}
                </div>
              )}

              <div className="flex gap-2 sm:gap-4 justify-center">
                <button
                  onClick={startGame}
                  onPointerDown={(e) => e.stopPropagation()}
                  onTouchStart={(e) => { e.stopPropagation(); }}
                  className={btnStyle}
                  style={{ ...gradientText, fontSize: 'clamp(1rem, 4vw, 1.5rem)', border: 'none', padding: '12px 24px', touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent', cursor: 'pointer', position: 'relative', zIndex: 10000 }}
                >
                  {t(lang, 'retry')}
                </button>
                <button
                  onClick={endRun}
                  onPointerDown={(e) => e.stopPropagation()}
                  onTouchStart={(e) => { e.stopPropagation(); }}
                  className={btnStyle}
                  style={{ ...gradientText, fontSize: 'clamp(1rem, 4vw, 1.5rem)', border: 'none', padding: '12px 24px', touchAction: 'manipulation', WebkitTapHighlightColor: 'transparent', cursor: 'pointer', position: 'relative', zIndex: 10000 }}
                >
                  {t(lang, 'home')}
                </button>
              </div>
            </div>
          </div>
        )}
        <div className="void-game-controls absolute bottom-4 left-4 text-gray-600 text-xs hidden md:block pointer-events-none z-10">{lang === 'it' ? 'WASD/Frecce: Muovi | ESC/P: Pausa' : lang === 'en' ? 'WASD/Arrows: Move | ESC/P: Pause' : lang === 'es' ? 'WASD/Flechas: Mover | ESC/P: Pausa' : lang === 'fr' ? 'WASD/Flèches: Déplacer | ESC/P: Pause' : 'WASD/方向键: 移动 | ESC/P: 暂停'}</div>

        {/* Modal Statistiche Danni */}
        {showDamageStats && (
          <div className="void-game-overlay void-damage-overlay fixed inset-0 flex items-center justify-center bg-black/90 backdrop-blur-sm z-[10001] overflow-y-auto py-4" style={{ pointerEvents: 'auto' }}>
            <div className="void-overlay-panel text-center max-w-[600px] w-full px-3 sm:px-5" style={{ pointerEvents: 'auto' }}>
              <h2 className="font-bold text-2xl sm:text-3xl mb-4 text-purple-400">⚔️ {t(lang, 'total_damage_per_ability')}</h2>
              <div className="bg-black/80 border-2 border-purple-500/60 rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-4 max-h-[60vh] overflow-y-auto">
                {Object.keys(gameStateRef.current.abilityDamageStats).length === 0 ? (
                  <p className="text-gray-400 text-sm">{t(lang, 'no_damage_dealt')}</p>
                ) : (
                  <div className="space-y-3">
                    {Object.entries(gameStateRef.current.abilityDamageStats)
                      .sort((a, b) => b[1] - a[1])
                      .map(([abilityType, damage]) => {
                        const abilityInfo = getAbilityInfo(abilityType as any);
                        return (
                          <div key={abilityType} className="flex items-center justify-between p-3 rounded-lg" style={{ background: `${abilityInfo.color}20`, border: `1px solid ${abilityInfo.color}40` }}>
                            <div className="flex items-center gap-3">
                              <AbilityIcon type={abilityType} color={abilityInfo.color} size={32} />
                              <div className="text-left">
                                <p className="font-bold text-sm" style={{ color: abilityInfo.color }}>{t(lang, abilityInfo.name)}</p>
                              </div>
                            </div>
                            <p className="text-white font-bold text-lg">{damage.toLocaleString()}</p>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
              <button
                onClick={() => setShowDamageStats(false)}
                className="w-full py-3 rounded-xl font-bold text-base transition-all hover:scale-105 active:scale-95"
                style={{
                  touchAction: 'manipulation',
                  WebkitTapHighlightColor: 'transparent',
                  cursor: 'pointer',
                  background: 'linear-gradient(135deg, rgba(168, 85, 247, 0.3) 0%, rgba(236, 72, 153, 0.3) 100%)',
                  border: '2px solid rgba(168, 85, 247, 0.6)',
                  color: '#a855f7'
                }}
              >
                ✖ Chiudi
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return null;
}