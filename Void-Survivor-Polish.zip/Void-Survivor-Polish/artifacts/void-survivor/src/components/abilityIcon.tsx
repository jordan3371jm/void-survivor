import React from 'react';

interface AbilityIconProps {
  type: string;
  color: string;
  size?: number;
}

const ASSET_BASE: string = ((import.meta as any).env && (import.meta as any).env.BASE_URL) || '/';

/** Abilità con immagine in public/assets/abilities/<tipo>.webp (le altre usano il disegno SVG). */
export const ABILITY_IMAGE_TYPES = new Set<string>([
  'photon_gun', 'ion_gun', 'drone_swarm', 'gravity_waves', 'void_lance', 'cryo_lance', 'energy_shield', 'asteroid_fragment',
  'antimatter_bomb', 'laser_swords', 'homing_laser', 'kinetic_darts', 'meteor', 'neutronium_boomerang', 'orbiting_satellites',
  'plasma_flamethrower', 'gravity_field', 'corrosive_nebula', 'quantum_bounce', 'ion_storm', 'stellar_blackhole', 'probe_x', 'probe_y',
  'passive_fusion_core', 'passive_plating', 'passive_neutronium_heart', 'passive_regen_core', 'passive_void_tome',
  'passive_stellar_candelabrum', 'passive_kinetic_accelerator', 'passive_quantum_binder', 'passive_molecular_replicator',
  'passive_ionic_thrusters', 'passive_gravity_field', 'passive_stellar_fortune', 'passive_galactic_crown', 'passive_cosmic_dust',
  'passive_quantum_reactor', 'passive_pulsar_heart', 'passive_galactic_coin',
]);

export const AbilityIcon: React.FC<AbilityIconProps> = ({ type, color, size = 48 }) => {
  if (ABILITY_IMAGE_TYPES.has(type)) {
    return (
      <img
        src={`${ASSET_BASE}assets/abilities/${type}.webp`}
        width={size}
        height={size}
        alt={type}
        draggable={false}
        style={{ width: size, height: size, objectFit: 'contain', flexShrink: 0 }}
      />
    );
  }
  const renderIcon = () => {
    switch (type) {
      case 'photon_gun':
      case 'ion_gun':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <rect x="8" y="18" width="12" height="6" rx="1" fill={color}/>
            <rect x="20" y="19" width="8" height="4" fill={color}/>
            <line x1="28" y1="21" x2="36" y2="21" stroke={color} strokeWidth="2"/>
            <circle cx="36" cy="21" r="2" fill={color} opacity="0.7"/>
          </svg>
        );
      case 'drone_swarm':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="12" cy="14" r="3" fill={color}/>
            <circle cx="28" cy="14" r="3" fill={color}/>
            <circle cx="20" cy="26" r="3" fill={color}/>
          </svg>
        );
      case 'gravity_waves':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            {[1, 2, 3].map(i => (
              <circle key={i} cx="20" cy="20" r={i * 4} stroke={color} strokeWidth="2" fill="none"/>
            ))}
          </svg>
        );
      case 'void_lance':
      case 'cryo_lance':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <line x1="8" y1="20" x2="32" y2="20" stroke={color} strokeWidth="2"/>
            <polygon points="32,20 28,17 28,23" fill={color}/>
          </svg>
        );
      case 'energy_shield':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="10" stroke={color} strokeWidth="2" fill={color} opacity="0.3"/>
            <circle cx="20" cy="20" r="4" fill={color}/>
          </svg>
        );
      case 'asteroid_fragment':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 20 10 L 28 14 L 30 22 L 26 30 L 18 32 L 12 26 L 10 18 L 14 12 Z" fill={color}/>
          </svg>
        );
      case 'antimatter_bomb':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="22" r="8" fill={color}/>
            <rect x="18" y="10" width="4" height="6" fill={color}/>
            <circle cx="20" cy="22" r="12" stroke={color} strokeWidth="1.5" fill="none" opacity="0.4"/>
          </svg>
        );
      case 'laser_swords':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <line x1="10" y1="10" x2="20" y2="20" stroke={color} strokeWidth="3"/>
            <line x1="30" y1="10" x2="20" y2="20" stroke={color} strokeWidth="3"/>
            <circle cx="20" cy="20" r="3" fill={color}/>
          </svg>
        );
      case 'homing_laser':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <line x1="8" y1="20" x2="28" y2="20" stroke={color} strokeWidth="2"/>
            <circle cx="30" cy="20" r="4" stroke={color} strokeWidth="2" fill="none"/>
            <circle cx="30" cy="20" r="1.5" fill={color}/>
          </svg>
        );
      case 'kinetic_darts':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <line x1="8" y1="14" x2="28" y2="14" stroke={color} strokeWidth="2"/>
            <polygon points="28,14 24,12 24,16" fill={color}/>
            <line x1="8" y1="20" x2="32" y2="20" stroke={color} strokeWidth="2"/>
            <polygon points="32,20 28,18 28,22" fill={color}/>
            <line x1="8" y1="26" x2="28" y2="26" stroke={color} strokeWidth="2"/>
            <polygon points="28,26 24,24 24,28" fill={color}/>
          </svg>
        );
      case 'meteor':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="24" cy="24" r="8" fill={color}/>
            <path d="M 16 16 L 10 10 M 18 14 L 14 8" stroke={color} strokeWidth="2" opacity="0.6"/>
          </svg>
        );
      case 'neutronium_boomerang':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 10 20 Q 10 10, 20 10 Q 30 10, 30 20" stroke={color} strokeWidth="3" fill="none"/>
          </svg>
        );
      case 'orbiting_satellites':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="4" fill={color} opacity="0.5"/>
            <circle cx="8" cy="20" r="3" fill={color}/>
            <circle cx="32" cy="20" r="3" fill={color}/>
            <circle cx="20" cy="8" r="2.5" fill={color}/>
          </svg>
        );
      case 'plasma_flamethrower':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 12 28 Q 10 20, 14 16 Q 16 12, 20 10 Q 24 12, 26 16 Q 30 20, 28 28 Z" fill={color} opacity="0.7"/>
          </svg>
        );
      case 'gravity_field':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="12" stroke={color} strokeWidth="2" fill={color} opacity="0.2"/>
            <circle cx="20" cy="20" r="8" stroke={color} strokeWidth="1.5" fill="none" opacity="0.5"/>
            <circle cx="20" cy="20" r="4" fill={color} opacity="0.6"/>
          </svg>
        );
      case 'corrosive_nebula':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="16" cy="20" r="6" fill={color} opacity="0.6"/>
            <circle cx="24" cy="18" r="5" fill={color} opacity="0.6"/>
            <circle cx="22" cy="24" r="5" fill={color} opacity="0.6"/>
          </svg>
        );
      case 'quantum_bounce':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="12" cy="28" r="4" fill={color}/>
            <path d="M 12 28 L 20 12 L 28 28" stroke={color} strokeWidth="2" fill="none" strokeDasharray="3,2"/>
            <circle cx="28" cy="28" r="4" fill={color}/>
          </svg>
        );
      case 'ion_storm':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 16 8 L 14 18 L 18 18 L 16 28" stroke={color} strokeWidth="2.5" fill="none"/>
            <path d="M 24 10 L 22 20 L 26 20 L 24 30" stroke={color} strokeWidth="2.5" fill="none"/>
          </svg>
        );
      case 'stellar_blackhole':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="10" fill={color}/>
            <circle cx="20" cy="20" r="14" stroke={color} strokeWidth="2" fill="none" opacity="0.6"/>
          </svg>
        );
      case 'probe_x':
      case 'probe_y':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="16" r="6" fill={color}/>
            <rect x="18" y="22" width="4" height="8" fill={color}/>
            <line x1="20" y1="30" x2="20" y2="36" stroke={color} strokeWidth="2"/>
          </svg>
        );
      case 'passive_fusion_core':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="4" fill={color}/>
            <ellipse cx="20" cy="20" rx="12" ry="4" stroke={color} strokeWidth="1.5" fill="none" transform="rotate(0 20 20)"/>
            <ellipse cx="20" cy="20" rx="12" ry="4" stroke={color} strokeWidth="1.5" fill="none" transform="rotate(60 20 20)"/>
            <ellipse cx="20" cy="20" rx="12" ry="4" stroke={color} strokeWidth="1.5" fill="none" transform="rotate(120 20 20)"/>
          </svg>
        );
      case 'passive_plating':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 20 8 L 30 14 L 30 24 Q 30 32 20 34 Q 10 32 10 24 L 10 14 Z" fill={color} opacity="0.7"/>
            <path d="M 20 8 L 30 14 L 30 24 Q 30 32 20 34 Q 10 32 10 24 L 10 14 Z" stroke={color} strokeWidth="2" fill="none"/>
          </svg>
        );
      case 'passive_neutronium_heart':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 20 30 Q 10 22 10 16 Q 10 10 15 10 Q 18 10 20 13 Q 22 10 25 10 Q 30 10 30 16 Q 30 22 20 30 Z" fill={color}/>
          </svg>
        );
      case 'passive_regen_core':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 20 30 Q 10 22 10 16 Q 10 10 15 10 Q 18 10 20 13 Q 22 10 25 10 Q 30 10 30 16 Q 30 22 20 30 Z" fill={color} opacity="0.7"/>
            <line x1="16" y1="20" x2="24" y2="20" stroke="white" strokeWidth="2"/>
            <line x1="20" y1="16" x2="20" y2="24" stroke="white" strokeWidth="2"/>
          </svg>
        );
      case 'passive_void_tome':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <rect x="10" y="8" width="20" height="24" rx="2" fill={color} opacity="0.7"/>
            <rect x="10" y="8" width="20" height="24" rx="2" stroke={color} strokeWidth="2" fill="none"/>
            <line x1="15" y1="14" x2="25" y2="14" stroke="white" strokeWidth="1"/>
            <line x1="15" y1="18" x2="25" y2="18" stroke="white" strokeWidth="1"/>
          </svg>
        );
      case 'passive_stellar_candelabrum':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <line x1="20" y1="32" x2="20" y2="12" stroke={color} strokeWidth="2"/>
            <line x1="12" y1="16" x2="28" y2="16" stroke={color} strokeWidth="2"/>
            <circle cx="20" cy="10" r="3" fill={color}/>
            <circle cx="12" cy="14" r="2" fill={color}/>
            <circle cx="28" cy="14" r="2" fill={color}/>
          </svg>
        );
      case 'passive_kinetic_accelerator':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <line x1="10" y1="20" x2="28" y2="20" stroke={color} strokeWidth="2"/>
            <line x1="24" y1="16" x2="30" y2="20" stroke={color} strokeWidth="2"/>
            <line x1="24" y1="24" x2="30" y2="20" stroke={color} strokeWidth="2"/>
            <line x1="8" y1="18" x2="14" y2="18" stroke={color} strokeWidth="1.5" opacity="0.6"/>
            <line x1="8" y1="22" x2="14" y2="22" stroke={color} strokeWidth="1.5" opacity="0.6"/>
          </svg>
        );
      case 'passive_quantum_binder':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="15" cy="20" r="8" stroke={color} strokeWidth="2" fill="none"/>
            <circle cx="25" cy="20" r="8" stroke={color} strokeWidth="2" fill="none"/>
            <circle cx="20" cy="20" r="3" fill={color}/>
          </svg>
        );
      case 'passive_molecular_replicator':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="14" cy="16" r="4" fill={color} opacity="0.7"/>
            <circle cx="14" cy="24" r="4" fill={color} opacity="0.7"/>
            <circle cx="26" cy="16" r="4" fill={color}/>
            <circle cx="26" cy="24" r="4" fill={color}/>
          </svg>
        );
      case 'passive_ionic_thrusters':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 20 8 L 26 16 L 26 28 L 14 28 L 14 16 Z" fill={color} opacity="0.7"/>
            <path d="M 16 28 L 14 34 L 20 30 L 26 34 L 24 28" stroke={color} strokeWidth="2" fill={color} opacity="0.5"/>
          </svg>
        );
      case 'passive_gravity_field':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 12 12 L 12 24 Q 12 32 20 32 Q 28 32 28 24 L 28 12" stroke={color} strokeWidth="3" fill="none"/>
            <rect x="10" y="10" width="4" height="6" fill={color}/>
            <rect x="26" y="10" width="4" height="6" fill={color}/>
          </svg>
        );
      case 'passive_stellar_fortune':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="14" r="5" fill={color} opacity="0.7"/>
            <circle cx="20" cy="26" r="5" fill={color} opacity="0.7"/>
            <circle cx="14" cy="20" r="5" fill={color} opacity="0.7"/>
            <circle cx="26" cy="20" r="5" fill={color} opacity="0.7"/>
            <circle cx="20" cy="20" r="3" fill={color}/>
          </svg>
        );
      case 'passive_galactic_crown':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 10 26 L 12 16 L 16 22 L 20 14 L 24 22 L 28 16 L 30 26 Z" fill={color} opacity="0.7"/>
            <path d="M 10 26 L 12 16 L 16 22 L 20 14 L 24 22 L 28 16 L 30 26 Z" stroke={color} strokeWidth="2" fill="none"/>
            <circle cx="20" cy="14" r="2" fill="white"/>
          </svg>
        );
      case 'passive_cosmic_dust':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="12" cy="12" r="2" fill={color}/>
            <circle cx="28" cy="14" r="1.5" fill={color}/>
            <circle cx="20" cy="20" r="2.5" fill={color}/>
            <circle cx="14" cy="28" r="1.5" fill={color}/>
            <circle cx="26" cy="26" r="2" fill={color}/>
          </svg>
        );
      case 'passive_quantum_reactor':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <rect x="12" y="12" width="16" height="16" rx="2" stroke={color} strokeWidth="2" fill="none"/>
            <circle cx="20" cy="20" r="4" fill={color}/>
            <line x1="20" y1="8" x2="20" y2="12" stroke={color} strokeWidth="2"/>
            <line x1="20" y1="28" x2="20" y2="32" stroke={color} strokeWidth="2"/>
          </svg>
        );
      case 'passive_pulsar_heart':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <path d="M 20 30 Q 10 22 10 16 Q 10 10 15 10 Q 18 10 20 13 Q 22 10 25 10 Q 30 10 30 16 Q 30 22 20 30 Z" fill={color} opacity="0.8"/>
            <circle cx="20" cy="20" r="14" stroke={color} strokeWidth="1" fill="none" opacity="0.3"/>
          </svg>
        );
      case 'passive_galactic_coin':
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <circle cx="20" cy="20" r="12" fill={color} opacity="0.7"/>
            <circle cx="20" cy="20" r="12" stroke={color} strokeWidth="2" fill="none"/>
            <circle cx="20" cy="20" r="9" stroke={color} strokeWidth="1" fill="none" opacity="0.5"/>
            <text x="20" y="25" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">$</text>
          </svg>
        );
      default:
        return (
          <svg width={size} height={size} viewBox="0 0 40 40">
            <polygon points="20,10 23,17 30,17 25,22 27,30 20,25 13,30 15,22 10,17 17,17" fill={color}/>
          </svg>
        );
    }
  };
  return <div style={{ display: 'inline-block' }}>{renderIcon()}</div>;
};