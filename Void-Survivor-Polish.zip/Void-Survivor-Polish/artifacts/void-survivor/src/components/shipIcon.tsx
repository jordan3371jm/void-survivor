import React from 'react';

interface ShipIconProps {
  shipType: string;
  color: string;
  size?: number;
}

const ASSET_BASE: string = ((import.meta as any).env && (import.meta as any).env.BASE_URL) || '/';

/** Navi che hanno un'immagine in public/assets/ships/<tipo>.webp (le altre usano il disegno SVG). */
export const SHIP_IMAGE_TYPES = new Set<string>([
  'starter', 'fire_ship', 'laser_ship', 'electric_ship', 'nuclear_ship', 'shadow_ship', 'mechanical_ship', 'bio_ship',
  'photon_ship', 'ion_ship', 'drone_ship', 'gravity_ship', 'void_ship', 'cryo_ship', 'shield_ship', 'asteroid_ship',
  'kinetic_ship', 'meteor_ship', 'boomerang_ship', 'quantum_ship', 'blackhole_ship', 'probe_x_ship', 'probe_y_ship',
  'tie_fighter_ship', 'viper_ship', 'federation_ship',
]);

export const ShipIcon: React.FC<ShipIconProps> = ({ shipType, color, size = 64 }) => {
  if (SHIP_IMAGE_TYPES.has(shipType)) {
    return (
      <img
        src={`${ASSET_BASE}assets/ships/${shipType}.webp`}
        width={size}
        height={size}
        alt={shipType}
        draggable={false}
        style={{ width: size, height: size, objectFit: 'contain', filter: `drop-shadow(0 0 6px ${color}66)` }}
      />
    );
  }
  const renderShip = () => {
    switch (shipType) {
      case 'starter':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="65" rx="22" ry="7" fill="#000000" opacity="0.3"/>
            <ellipse cx="40" cy="38" rx="6" ry="16" fill="#2a4a2a" stroke="#1a3a1a" strokeWidth="1.2"/>
            <ellipse cx="40" cy="38" rx="6" ry="16" fill="url(#starterGradient)" opacity="0.7"/>
            <path d="M 34 35 Q 20 30 15 20 Q 18 18 22 20 Q 28 25 34 32 Z" fill="#1a3a1a" stroke="#0a2a0a" strokeWidth="0.8"/>
            <path d="M 46 35 Q 60 30 65 20 Q 62 18 58 20 Q 52 25 46 32 Z" fill="#1a3a1a" stroke="#0a2a0a" strokeWidth="0.8"/>
            <path d="M 15 20 Q 13 18 14 16 Q 16 17 18 18 Z" fill="#0a2a0a"/>
            <path d="M 65 20 Q 67 18 66 16 Q 64 17 62 18 Z" fill="#0a2a0a"/>
            <rect x="18" y="22" width="3" height="6" fill="#3a3a3a" stroke="#2a2a2a" strokeWidth="0.5" rx="1"/>
            <circle cx="19.5" cy="22" r="1.5" fill="#ff6600" opacity="0.8"/>
            <rect x="59" y="22" width="3" height="6" fill="#3a3a3a" stroke="#2a2a2a" strokeWidth="0.5" rx="1"/>
            <circle cx="60.5" cy="22" r="1.5" fill="#ff6600" opacity="0.8"/>
            <path d="M 40 22 L 37 30 L 43 30 Z" fill="#3a5a3a" stroke="#2a4a2a" strokeWidth="0.6"/>
            <path d="M 37 52 L 40 58 L 43 52 Z" fill="#2a4a2a" stroke="#1a3a1a" strokeWidth="0.5"/>
            <ellipse cx="40" cy="56" rx="3" ry="2" fill="#00ff00" opacity="0.8"/>
            <ellipse cx="40" cy="56" rx="2" ry="1.2" fill="#88ff88" opacity="0.7"/>
            <line x1="40" y1="25" x2="40" y2="52" stroke="#1a3a1a" strokeWidth="0.5" opacity="0.6"/>
            <ellipse cx="40" cy="35" rx="3" ry="2" fill="#4a6a4a" opacity="0.5"/>
            <ellipse cx="40" cy="32" rx="2.5" ry="1.8" fill="#88ff88" opacity="0.6"/>
            <line x1="22" y1="28" x2="30" y2="32" stroke="#00ff00" strokeWidth="0.5" opacity="0.4"/>
            <line x1="58" y1="28" x2="50" y2="32" stroke="#00ff00" strokeWidth="0.5" opacity="0.4"/>
            <defs>
              <linearGradient id="starterGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3a5a3a"/>
                <stop offset="100%" stopColor="#1a3a1a"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'fire_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="68" rx="22" ry="7" fill="#000000" opacity="0.3"/>
            <ellipse cx="40" cy="35" rx="8" ry="20" fill="#cc3300" stroke="#ff4400" strokeWidth="1.2"/>
            <ellipse cx="40" cy="35" rx="8" ry="20" fill="url(#fireGradient)" opacity="0.7"/>
            <path d="M 40 15 L 36 25 L 44 25 Z" fill="#ff5500" stroke="#ff6600" strokeWidth="0.8"/>
            <path d="M 32 30 L 15 38 L 18 45 L 32 42 Z" fill="#aa2200" stroke="#cc3300" strokeWidth="1"/>
            <path d="M 48 30 L 65 38 L 62 45 L 48 42 Z" fill="#aa2200" stroke="#cc3300" strokeWidth="1"/>
            <path d="M 15 38 L 12 36 L 18 45 Z" fill="#881100"/>
            <path d="M 65 38 L 68 36 L 62 45 Z" fill="#881100"/>
            <rect x="35" y="50" width="10" height="8" fill="#882200" stroke="#aa3300" strokeWidth="0.8" rx="1"/>
            <ellipse cx="40" cy="58" rx="6" ry="4" fill="#ff6600" stroke="#ff8800" strokeWidth="1"/>
            <ellipse cx="40" cy="58" rx="4" ry="2.5" fill="#ffaa00" opacity="0.8"/>
            <path d="M 36 62 Q 38 68 40 70 Q 42 68 44 62" fill="#ff4400" opacity="0.7"/>
            <path d="M 38 62 Q 39 66 40 68 Q 41 66 42 62" fill="#ffcc00" opacity="0.8"/>
            <line x1="40" y1="20" x2="40" y2="50" stroke="#ff6600" strokeWidth="0.8" opacity="0.6"/>
            <circle cx="40" cy="30" r="2" fill="#ffcc00" opacity="0.8"/>
            <circle cx="40" cy="40" r="1.5" fill="#ff8800" opacity="0.7"/>
            <rect x="36" y="28" width="2" height="3" fill="#ffaa00" opacity="0.6" rx="0.5"/>
            <rect x="42" y="28" width="2" height="3" fill="#ffaa00" opacity="0.6" rx="0.5"/>
            <defs>
              <linearGradient id="fireGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ff6600"/>
                <stop offset="100%" stopColor="#cc3300"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'laser_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="65" rx="30" ry="8" fill="#000000" opacity="0.3"/>
            <path d="M 40 10 L 70 40 L 40 70 L 10 40 Z" fill="#8a1a1a" stroke="#aa2222" strokeWidth="1.5"/>
            <path d="M 40 10 L 70 40 L 40 70 L 10 40 Z" fill="url(#laserGradient)" opacity="0.6"/>
            <path d="M 40 18 L 62 40 L 40 62 L 18 40 Z" fill="#6a0a0a" stroke="#8a1a1a" strokeWidth="1"/>
            <line x1="40" y1="10" x2="40" y2="70" stroke="#ff3333" strokeWidth="1" opacity="0.7"/>
            <line x1="10" y1="40" x2="70" y2="40" stroke="#ff3333" strokeWidth="1" opacity="0.7"/>
            <circle cx="40" cy="10" r="3" fill="#aa2222" stroke="#ff3333" strokeWidth="0.5"/>
            <circle cx="70" cy="40" r="3" fill="#aa2222" stroke="#ff3333" strokeWidth="0.5"/>
            <circle cx="40" cy="70" r="3" fill="#aa2222" stroke="#ff3333" strokeWidth="0.5"/>
            <circle cx="10" cy="40" r="3" fill="#aa2222" stroke="#ff3333" strokeWidth="0.5"/>
            <circle cx="40" cy="10" r="1.5" fill="#ff0000" opacity="0.9"/>
            <circle cx="70" cy="40" r="1.5" fill="#ff0000" opacity="0.9"/>
            <circle cx="40" cy="70" r="1.5" fill="#ff0000" opacity="0.9"/>
            <circle cx="10" cy="40" r="1.5" fill="#ff0000" opacity="0.9"/>
            <circle cx="40" cy="40" r="8" fill="#4a0000" stroke="#ff3333" strokeWidth="1.5"/>
            <circle cx="40" cy="40" r="5" fill="#ff0000" opacity="0.8"/>
            <circle cx="40" cy="40" r="3" fill="#ffffff" opacity="0.6"/>
            <rect x="25" y="38" width="8" height="4" fill="#aa2222" opacity="0.7"/>
            <rect x="47" y="38" width="8" height="4" fill="#aa2222" opacity="0.7"/>
            <rect x="38" y="25" width="4" height="8" fill="#aa2222" opacity="0.7"/>
            <rect x="38" y="47" width="4" height="8" fill="#aa2222" opacity="0.7"/>
            <defs>
              <linearGradient id="laserGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#aa2222"/>
                <stop offset="100%" stopColor="#6a0a0a"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'electric_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="65" rx="25" ry="8" fill="#000000" opacity="0.3"/>
            <ellipse cx="40" cy="32" rx="10" ry="15" fill="#5a5a5a" stroke="#3a3a3a" strokeWidth="1.2"/>
            <ellipse cx="40" cy="32" rx="10" ry="15" fill="url(#electricGradient)" opacity="0.7"/>
            <path d="M 30 35 L 8 48 L 12 58 L 32 48 Z" fill="#4a4a4a" stroke="#2a2a2a" strokeWidth="1"/>
            <path d="M 50 35 L 72 48 L 68 58 L 48 48 Z" fill="#4a4a4a" stroke="#2a2a2a" strokeWidth="1"/>
            <path d="M 8 48 L 5 45 L 12 58 Z" fill="#3a3a3a"/>
            <path d="M 72 48 L 75 45 L 68 58 Z" fill="#3a3a3a"/>
            <path d="M 40 18 L 34 32 L 46 32 Z" fill="#6a6a6a" stroke="#4a4a4a" strokeWidth="0.8"/>
            <rect x="34" y="48" width="4" height="10" fill="#3a3a3a" stroke="#2a2a2a" strokeWidth="0.6"/>
            <rect x="42" y="48" width="4" height="10" fill="#3a3a3a" stroke="#2a2a2a" strokeWidth="0.6"/>
            <circle cx="36" cy="58" r="2" fill="#ffff00" opacity="0.9"/>
            <circle cx="44" cy="58" r="2" fill="#ffff00" opacity="0.9"/>
            <circle cx="40" cy="60" r="1.5" fill="#ffcc00" opacity="0.8"/>
            <line x1="40" y1="22" x2="40" y2="42" stroke="#4a4a4a" strokeWidth="0.6" opacity="0.7"/>
            <circle cx="40" cy="28" r="2.5" fill="#ffcc00" opacity="0.8"/>
            <circle cx="40" cy="36" r="2" fill="#ffff00" opacity="0.7"/>
            <rect x="36" y="32" width="8" height="3" fill="#ffff88" opacity="0.6" rx="0.8"/>
            <line x1="20" y1="42" x2="30" y2="45" stroke="#ffff00" strokeWidth="0.8" opacity="0.5"/>
            <line x1="60" y1="42" x2="50" y2="45" stroke="#ffff00" strokeWidth="0.8" opacity="0.5"/>
            <defs>
              <linearGradient id="electricGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7a7a7a"/>
                <stop offset="100%" stopColor="#4a4a4a"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'nuclear_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="65" rx="22" ry="7" fill="#000000" opacity="0.3"/>
            <path d="M 40 15 L 55 25 L 55 45 L 40 55 L 25 45 L 25 25 Z" fill="#2a3a4a" stroke="#1a2a3a" strokeWidth="1.2"/>
            <path d="M 40 15 L 55 25 L 55 45 L 40 55 L 25 45 L 25 25 Z" fill="url(#nuclearGradient)" opacity="0.6"/>
            <path d="M 40 15 L 50 22 L 50 38 L 40 45 L 30 38 L 30 22 Z" fill="#3a4a5a" stroke="#2a3a4a" strokeWidth="0.8"/>
            <rect x="15" y="30" width="10" height="15" fill="#1a2a3a" stroke="#0a1a2a" strokeWidth="0.8" rx="2"/>
            <rect x="55" y="30" width="10" height="15" fill="#1a2a3a" stroke="#0a1a2a" strokeWidth="0.8" rx="2"/>
            <line x1="17" y1="35" x2="23" y2="35" stroke="#4a5a6a" strokeWidth="0.6"/>
            <line x1="17" y1="40" x2="23" y2="40" stroke="#4a5a6a" strokeWidth="0.6"/>
            <line x1="57" y1="35" x2="63" y2="35" stroke="#4a5a6a" strokeWidth="0.6"/>
            <line x1="57" y1="40" x2="63" y2="40" stroke="#4a5a6a" strokeWidth="0.6"/>
            <circle cx="40" cy="35" r="6" fill="#00ff00" opacity="0.8"/>
            <circle cx="40" cy="35" r="4" fill="#88ff88" opacity="0.9"/>
            <circle cx="40" cy="35" r="2" fill="#ffffff" opacity="0.7"/>
            <rect x="35" y="42" width="10" height="3" fill="#4a5a6a" stroke="#3a4a5a" strokeWidth="0.5" rx="1"/>
            <rect x="37" y="47" width="6" height="2" fill="#3a4a5a" stroke="#2a3a4a" strokeWidth="0.5" rx="0.5"/>
            <circle cx="35" cy="55" r="2.5" fill="#00ccff" opacity="0.8"/>
            <circle cx="45" cy="55" r="2.5" fill="#00ccff" opacity="0.8"/>
            <circle cx="40" cy="58" r="2" fill="#00ff00" opacity="0.7"/>
            <defs>
              <linearGradient id="nuclearGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#4a5a6a"/>
                <stop offset="100%" stopColor="#1a2a3a"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'shadow_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="62" rx="22" ry="7" fill="#000000" opacity="0.3"/>
            <ellipse cx="40" cy="40" rx="10" ry="15" fill="#2a4a2a" stroke="#1a3a1a" strokeWidth="1"/>
            <ellipse cx="40" cy="40" rx="10" ry="15" fill="url(#shadowGradient)" opacity="0.6"/>
            <path d="M 30 40 L 10 30 L 12 45 L 28 45 Z" fill="#1a3a1a" stroke="#0a2a0a" strokeWidth="0.8"/>
            <path d="M 50 40 L 70 30 L 68 45 L 52 45 Z" fill="#1a3a1a" stroke="#0a2a0a" strokeWidth="0.8"/>
            <path d="M 10 30 L 8 28 L 12 45 Z" fill="#0a2a0a"/>
            <path d="M 70 30 L 72 28 L 68 45 Z" fill="#0a2a0a"/>
            <path d="M 40 25 L 35 40 L 45 40 Z" fill="#3a5a3a" stroke="#2a4a2a" strokeWidth="0.5"/>
            <path d="M 35 50 L 40 58 L 45 50 Z" fill="#2a4a2a" stroke="#1a3a1a" strokeWidth="0.5"/>
            <circle cx="37" cy="55" r="2" fill="#00ff00" opacity="0.8"/>
            <circle cx="43" cy="55" r="2" fill="#00ff00" opacity="0.8"/>
            <line x1="40" y1="28" x2="40" y2="52" stroke="#1a3a1a" strokeWidth="0.5" opacity="0.6"/>
            <ellipse cx="40" cy="38" rx="4" ry="3" fill="#4a6a4a" opacity="0.5"/>
            <ellipse cx="40" cy="35" rx="3" ry="2" fill="#88ff88" opacity="0.6"/>
            <line x1="20" y1="38" x2="28" y2="42" stroke="#00ff00" strokeWidth="0.5" opacity="0.4"/>
            <line x1="60" y1="38" x2="52" y2="42" stroke="#00ff00" strokeWidth="0.5" opacity="0.4"/>
            <defs>
              <linearGradient id="shadowGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3a5a3a"/>
                <stop offset="100%" stopColor="#1a3a1a"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'mechanical_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="55" rx="15" ry="10" fill="#ff8800" opacity="0.5"/>
            <rect x="25" y="25" width="30" height="30" fill={color} stroke="#ff8800" strokeWidth="1.5"/>
            <rect x="28" y="20" width="24" height="8" fill="#666666"/>
            <rect x="28" y="52" width="24" height="8" fill="#666666"/>
            <circle cx="40" cy="38" r="4" fill="#ff8800"/>
          </svg>
        );
      case 'bio_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="62" rx="20" ry="6" fill="#000000" opacity="0.3"/>
            <ellipse cx="40" cy="35" rx="9" ry="13" fill="#3a2a2a" stroke="#2a1a1a" strokeWidth="1"/>
            <ellipse cx="40" cy="35" rx="9" ry="13" fill="url(#bioGradient)" opacity="0.7"/>
            <path d="M 35 28 Q 40 25 45 28" stroke="#4a3a3a" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <path d="M 34 32 Q 40 30 46 32" stroke="#4a3a3a" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <path d="M 35 36 Q 40 34 45 36" stroke="#4a3a3a" strokeWidth="0.5" fill="none" opacity="0.6"/>
            <path d="M 31 38 Q 20 42 15 50 Q 16 53 18 55 Q 25 50 35 45 Z" fill="#2a1a1a" stroke="#1a0a0a" strokeWidth="0.8"/>
            <path d="M 49 38 Q 60 42 65 50 Q 64 53 62 55 Q 55 50 45 45 Z" fill="#2a1a1a" stroke="#1a0a0a" strokeWidth="0.8"/>
            <path d="M 15 50 Q 13 48 12 48 L 18 55 Z" fill="#1a0a0a"/>
            <path d="M 65 50 Q 67 48 68 48 L 62 55 Z" fill="#1a0a0a"/>
            <path d="M 40 22 Q 36 28 36 35 Q 40 33 44 35 Q 44 28 40 22 Z" fill="#4a3a3a" stroke="#3a2a2a" strokeWidth="0.6"/>
            <ellipse cx="37" cy="50" rx="2" ry="4" fill="#2a1a1a" stroke="#1a0a0a" strokeWidth="0.5"/>
            <ellipse cx="43" cy="50" rx="2" ry="4" fill="#2a1a1a" stroke="#1a0a0a" strokeWidth="0.5"/>
            <circle cx="37" cy="54" r="1.5" fill="#ff3300" opacity="0.9"/>
            <circle cx="43" cy="54" r="1.5" fill="#ff3300" opacity="0.9"/>
            <circle cx="40" cy="30" r="2" fill="#ff6600" opacity="0.7"/>
            <ellipse cx="40" cy="38" rx="3" ry="2" fill="#ff4400" opacity="0.5"/>
            <ellipse cx="40" cy="34" rx="2.5" ry="1.5" fill="#ff8888" opacity="0.6"/>
            <defs>
              <linearGradient id="bioGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#5a4a4a"/>
                <stop offset="100%" stopColor="#2a1a1a"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'photon_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 15 L 30 40 L 35 55 L 40 50 L 45 55 L 50 40 Z" fill="#ff3333" stroke="#ff6666" strokeWidth="1.5"/>
            <circle cx="40" cy="35" r="4" fill="#ff0000" opacity="0.8"/>
            <path d="M 30 40 L 20 45 L 25 50 Z" fill="#ff4444"/>
            <path d="M 50 40 L 60 45 L 55 50 Z" fill="#ff4444"/>
          </svg>
        );
      case 'ion_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 15 L 28 38 L 32 55 L 40 48 L 48 55 L 52 38 Z" fill="#3333ff" stroke="#6666ff" strokeWidth="1.5"/>
            <circle cx="40" cy="35" r="4" fill="#0000ff" opacity="0.8"/>
            <path d="M 28 38 L 18 42 L 22 48 Z" fill="#4444ff"/>
            <path d="M 52 38 L 62 42 L 58 48 Z" fill="#4444ff"/>
          </svg>
        );
      case 'drone_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <rect x="30" y="25" width="20" height="25" fill="#ffaa00" stroke="#ffcc44" strokeWidth="1.5" rx="2"/>
            <circle cx="35" cy="32" r="3" fill="#ff8800"/>
            <circle cx="45" cy="32" r="3" fill="#ff8800"/>
            <circle cx="40" cy="42" r="3" fill="#ff8800"/>
            <rect x="25" y="50" width="30" height="5" fill="#cc8800" rx="1"/>
          </svg>
        );
      case 'gravity_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <circle cx="40" cy="38" r="15" fill="#aa00ff" opacity="0.3"/>
            <circle cx="40" cy="38" r="10" fill="#aa00ff" opacity="0.5"/>
            <circle cx="40" cy="38" r="5" fill="#aa00ff" opacity="0.8"/>
            <path d="M 40 20 L 35 38 L 40 55 L 45 38 Z" fill="#8800cc" stroke="#aa00ff" strokeWidth="1"/>
          </svg>
        );
      case 'void_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 15 L 32 35 L 28 55 L 40 48 L 52 55 L 48 35 Z" fill="#660066" stroke="#880088" strokeWidth="1.5"/>
            <path d="M 40 20 L 40 45" stroke="#aa00aa" strokeWidth="2" opacity="0.7"/>
            <circle cx="40" cy="35" r="3" fill="#ff00ff" opacity="0.8"/>
          </svg>
        );
      case 'cryo_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 15 L 30 38 L 35 55 L 40 50 L 45 55 L 50 38 Z" fill="#00ffff" stroke="#88ffff" strokeWidth="1.5"/>
            <path d="M 40 20 L 35 35 L 40 45 L 45 35 Z" fill="#00cccc" opacity="0.7"/>
            <circle cx="40" cy="35" r="3" fill="#ffffff" opacity="0.9"/>
            <path d="M 30 38 L 20 42 L 25 48 Z" fill="#00dddd"/>
            <path d="M 50 38 L 60 42 L 55 48 Z" fill="#00dddd"/>
          </svg>
        );
      case 'shield_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <circle cx="40" cy="38" r="18" fill="#00ff88" opacity="0.2"/>
            <circle cx="40" cy="38" r="18" stroke="#00ff88" strokeWidth="2" fill="none"/>
            <path d="M 40 20 L 32 38 L 40 55 L 48 38 Z" fill="#00cc66" stroke="#00ff88" strokeWidth="1.5"/>
            <circle cx="40" cy="38" r="4" fill="#00ff88" opacity="0.8"/>
          </svg>
        );
      case 'asteroid_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 20 L 48 25 L 52 35 L 48 45 L 40 50 L 32 45 L 28 35 L 32 25 Z" fill="#886644" stroke="#664422" strokeWidth="1.5"/>
            <circle cx="38" cy="32" r="3" fill="#664422"/>
            <circle cx="44" cy="38" r="2" fill="#664422"/>
            <path d="M 40 20 L 40 50" stroke="#aa8866" strokeWidth="1" opacity="0.5"/>
          </svg>
        );
      case 'kinetic_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 15 L 35 35 L 30 55 L 40 48 L 50 55 L 45 35 Z" fill="#ff8800" stroke="#ffaa44" strokeWidth="1.5"/>
            <path d="M 40 20 L 38 35 L 40 45 L 42 35 Z" fill="#ff6600" opacity="0.8"/>
            <circle cx="40" cy="35" r="2" fill="#ffcc00" opacity="0.9"/>
          </svg>
        );
      case 'meteor_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <circle cx="40" cy="38" r="12" fill="#ff6600" stroke="#ff8800" strokeWidth="1.5"/>
            <path d="M 40 26 L 35 20 L 38 25 L 32 18 L 36 24 L 30 15" stroke="#ff4400" strokeWidth="2" fill="none" opacity="0.7"/>
            <path d="M 40 26 L 45 20 L 42 25 L 48 18 L 44 24 L 50 15" stroke="#ff4400" strokeWidth="2" fill="none" opacity="0.7"/>
            <circle cx="40" cy="38" r="5" fill="#ffaa00" opacity="0.8"/>
          </svg>
        );
      case 'boomerang_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 20 Q 25 25 20 40 Q 25 55 40 55 Q 55 55 60 40 Q 55 25 40 20 Z" fill="#aaaaff" stroke="#ccccff" strokeWidth="1.5"/>
            <path d="M 40 25 Q 30 30 28 40 Q 30 50 40 50 Q 50 50 52 40 Q 50 30 40 25 Z" fill="#8888ff" opacity="0.6"/>
            <circle cx="40" cy="38" r="3" fill="#ffffff" opacity="0.8"/>
          </svg>
        );
      case 'quantum_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <path d="M 40 20 L 30 35 L 40 50 L 50 35 Z" fill="#44ffff" stroke="#88ffff" strokeWidth="1.5"/>
            <path d="M 30 35 L 20 40 L 30 45 L 40 35 Z" fill="#22dddd" opacity="0.7"/>
            <path d="M 50 35 L 60 40 L 50 45 L 40 35 Z" fill="#22dddd" opacity="0.7"/>
            <circle cx="40" cy="35" r="3" fill="#ffffff" opacity="0.9"/>
          </svg>
        );
      case 'blackhole_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <circle cx="40" cy="38" r="15" fill="#000000"/>
            <circle cx="40" cy="38" r="15" stroke="#ffffff" strokeWidth="2" fill="none" opacity="0.3"/>
            <circle cx="40" cy="38" r="10" stroke="#ffffff" strokeWidth="1" fill="none" opacity="0.5"/>
            <circle cx="40" cy="38" r="5" fill="#ffffff" opacity="0.2"/>
            <path d="M 40 23 Q 50 30 55 38 Q 50 46 40 53 Q 30 46 25 38 Q 30 30 40 23 Z" stroke="#888888" strokeWidth="1" fill="none" opacity="0.4"/>
          </svg>
        );
      case 'probe_x_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <circle cx="40" cy="32" r="8" fill="#ff2222" stroke="#ff4444" strokeWidth="1.5"/>
            <rect x="36" y="40" width="8" height="12" fill="#cc0000" stroke="#ff2222" strokeWidth="1"/>
            <circle cx="40" cy="32" r="3" fill="#ffffff" opacity="0.8"/>
            <path d="M 32 45 L 28 50 L 32 52 Z" fill="#ff4444"/>
            <path d="M 48 45 L 52 50 L 48 52 Z" fill="#ff4444"/>
          </svg>
        );
      case 'probe_y_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="60" rx="18" ry="6" fill="#000000" opacity="0.3"/>
            <circle cx="40" cy="32" r="8" fill="#2222ff" stroke="#4444ff" strokeWidth="1.5"/>
            <rect x="36" y="40" width="8" height="12" fill="#0000cc" stroke="#2222ff" strokeWidth="1"/>
            <circle cx="40" cy="32" r="3" fill="#ffffff" opacity="0.8"/>
            <path d="M 32 45 L 28 50 L 32 52 Z" fill="#4444ff"/>
            <path d="M 48 45 L 52 50 L 48 52 Z" fill="#4444ff"/>
          </svg>
        );
      case 'tie_fighter_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="65" rx="25" ry="8" fill="#000000" opacity="0.3"/>
            <path d="M 15 20 L 25 25 L 25 55 L 15 60 L 5 55 L 5 25 Z" fill="#2a2a2a" stroke="#444444" strokeWidth="1.5"/>
            <path d="M 15 20 L 25 25 L 25 55 L 15 60 L 5 55 L 5 25 Z" fill="url(#tieGradient1)" opacity="0.6"/>
            <path d="M 65 20 L 75 25 L 75 55 L 65 60 L 55 55 L 55 25 Z" fill="#2a2a2a" stroke="#444444" strokeWidth="1.5"/>
            <path d="M 65 20 L 75 25 L 75 55 L 65 60 L 55 55 L 55 25 Z" fill="url(#tieGradient2)" opacity="0.6"/>
            <rect x="25" y="38" width="10" height="4" fill="#3a3a3a" stroke="#555555" strokeWidth="0.5"/>
            <rect x="45" y="38" width="10" height="4" fill="#3a3a3a" stroke="#555555" strokeWidth="0.5"/>
            <circle cx="40" cy="40" r="8" fill="#1a1a1a" stroke="#444444" strokeWidth="1.5"/>
            <circle cx="40" cy="40" r="8" fill="url(#tieCockpit)" opacity="0.7"/>
            <circle cx="40" cy="38" r="4" fill="#00aaff" opacity="0.8"/>
            <circle cx="40" cy="38" r="2.5" fill="#66ccff" opacity="0.6"/>
            <line x1="10" y1="30" x2="20" y2="30" stroke="#555555" strokeWidth="0.8"/>
            <line x1="10" y1="40" x2="20" y2="40" stroke="#555555" strokeWidth="0.8"/>
            <line x1="10" y1="50" x2="20" y2="50" stroke="#555555" strokeWidth="0.8"/>
            <line x1="60" y1="30" x2="70" y2="30" stroke="#555555" strokeWidth="0.8"/>
            <line x1="60" y1="40" x2="70" y2="40" stroke="#555555" strokeWidth="0.8"/>
            <line x1="60" y1="50" x2="70" y2="50" stroke="#555555" strokeWidth="0.8"/>
            <rect x="23" y="35" width="2" height="10" fill="#666666"/>
            <rect x="55" y="35" width="2" height="10" fill="#666666"/>
            <defs>
              <linearGradient id="tieGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3a3a3a"/>
                <stop offset="100%" stopColor="#1a1a1a"/>
              </linearGradient>
              <linearGradient id="tieGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#3a3a3a"/>
                <stop offset="100%" stopColor="#1a1a1a"/>
              </linearGradient>
              <radialGradient id="tieCockpit">
                <stop offset="0%" stopColor="#2a2a2a"/>
                <stop offset="100%" stopColor="#0a0a0a"/>
              </radialGradient>
            </defs>
          </svg>
        );
      case 'viper_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="65" rx="20" ry="6" fill="#000000" opacity="0.3"/>
            <ellipse cx="40" cy="40" rx="6" ry="18" fill="#5a5a5a" stroke="#777777" strokeWidth="1"/>
            <ellipse cx="40" cy="40" rx="6" ry="18" fill="url(#viperGradient)" opacity="0.7"/>
            <path d="M 40 22 L 37 30 L 43 30 Z" fill="#6a6a6a" stroke="#888888" strokeWidth="0.5"/>
            <path d="M 34 35 L 15 28 L 18 35 L 34 40 Z" fill="#4a4a4a" stroke="#666666" strokeWidth="0.8"/>
            <path d="M 46 35 L 65 28 L 62 35 L 46 40 Z" fill="#4a4a4a" stroke="#666666" strokeWidth="0.8"/>
            <path d="M 36 48 L 22 52 L 25 56 L 36 52 Z" fill="#3a3a3a" stroke="#555555" strokeWidth="0.6"/>
            <path d="M 44 48 L 58 52 L 55 56 L 44 52 Z" fill="#3a3a3a" stroke="#555555" strokeWidth="0.6"/>
            <ellipse cx="40" cy="58" rx="4" ry="2" fill="#00ccff" opacity="0.9"/>
            <ellipse cx="40" cy="58" rx="2.5" ry="1.2" fill="#66ffff" opacity="0.7"/>
            <path d="M 38 60 Q 40 68 42 60" fill="#00aaff" opacity="0.5"/>
            <ellipse cx="40" cy="32" rx="3" ry="4" fill="#88ccff" opacity="0.6"/>
            <ellipse cx="40" cy="31" rx="2" ry="2.5" fill="#aaddff" opacity="0.5"/>
            <line x1="40" y1="25" x2="40" y2="55" stroke="#666666" strokeWidth="0.5" opacity="0.6"/>
            <circle cx="40" cy="38" r="1.5" fill="#ffaa00" opacity="0.8"/>
            <rect x="20" y="30" width="3" height="1.5" fill="#888888"/>
            <rect x="57" y="30" width="3" height="1.5" fill="#888888"/>
            <defs>
              <linearGradient id="viperGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7a7a7a"/>
                <stop offset="100%" stopColor="#4a4a4a"/>
              </linearGradient>
            </defs>
          </svg>
        );
      case 'federation_ship':
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <ellipse cx="40" cy="65" rx="25" ry="8" fill="#000000" opacity="0.3"/>
            <ellipse cx="40" cy="35" rx="18" ry="10" fill="#cccccc" stroke="#999999" strokeWidth="1"/>
            <ellipse cx="40" cy="35" rx="18" ry="10" fill="url(#federationGradient)" opacity="0.6"/>
            <ellipse cx="40" cy="35" rx="16" ry="8" fill="none" stroke="#aaaaaa" strokeWidth="0.8"/>
            <ellipse cx="40" cy="33" rx="6" ry="4" fill="#dddddd" stroke="#bbbbbb" strokeWidth="0.8"/>
            <ellipse cx="40" cy="32" rx="4" ry="2.5" fill="#eeeeee" opacity="0.7"/>
            <circle cx="35" cy="35" r="1" fill="#00aaff" opacity="0.8"/>
            <circle cx="40" cy="35" r="1" fill="#00aaff" opacity="0.8"/>
            <circle cx="45" cy="35" r="1" fill="#00aaff" opacity="0.8"/>
            <rect x="38" y="40" width="4" height="8" fill="#bbbbbb" stroke="#999999" strokeWidth="0.5"/>
            <ellipse cx="40" cy="52" rx="8" ry="5" fill="#aaaaaa" stroke="#888888" strokeWidth="1"/>
            <ellipse cx="40" cy="52" rx="8" ry="5" fill="url(#federationGradient2)" opacity="0.5"/>
            <rect x="18" y="48" width="12" height="3" fill="#999999" stroke="#777777" strokeWidth="0.8" rx="1.5"/>
            <rect x="50" y="48" width="12" height="3" fill="#999999" stroke="#777777" strokeWidth="0.8" rx="1.5"/>
            <circle cx="19" cy="49.5" r="2" fill="#ff3300" opacity="0.9"/>
            <circle cx="61" cy="49.5" r="2" fill="#ff3300" opacity="0.9"/>
            <rect x="22" y="49" width="6" height="1" fill="#00ccff" opacity="0.7"/>
            <rect x="52" y="49" width="6" height="1" fill="#00ccff" opacity="0.7"/>
            <line x1="30" y1="49" x2="36" y2="52" stroke="#888888" strokeWidth="1.5"/>
            <line x1="50" y1="49" x2="44" y2="52" stroke="#888888" strokeWidth="1.5"/>
            <ellipse cx="40" cy="55" rx="3" ry="1.5" fill="#00ccff" opacity="0.6"/>
            <defs>
              <linearGradient id="federationGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#eeeeee"/>
                <stop offset="100%" stopColor="#bbbbbb"/>
              </linearGradient>
              <linearGradient id="federationGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#cccccc"/>
                <stop offset="100%" stopColor="#999999"/>
              </linearGradient>
            </defs>
          </svg>
        );
      default:
        return (
          <svg width={size} height={size} viewBox="0 0 80 80">
            <circle cx="40" cy="40" r="30" fill={color} opacity="0.3"/>
            <circle cx="40" cy="40" r="20" fill={color}/>
          </svg>
        );
    }
  };
  return <div style={{ display: 'inline-block' }}>{renderShip()}</div>;
};